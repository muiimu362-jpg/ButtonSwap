package com.muiimu.shabekura

import android.util.Log
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * ホストのスマホの中で動く小さなサーバー。
 * マイクラで「/connect 127.0.0.1:19131」すると、ここにつながる。
 * 1秒に5回、通話に入っている人の座標を querytarget で聞く。
 */
class McBridge(
    private val names: () -> List<String>,
    private val onPositions: (Map<String, Pos>) -> Unit,
    private val onLinked: (Boolean) -> Unit,
    private val onFail: (String) -> Unit,
) : WebSocketServer(InetSocketAddress("127.0.0.1", PORT)) {

    companion object {
        const val PORT = 19131
        const val COMMAND = "/connect 127.0.0.1:19131"
        private const val POLL_MS = 200L
        private const val TAG = "McBridge"
    }

    @Volatile private var conn: WebSocket? = null
    @Volatile private var alive = true
    private val pending = ConcurrentHashMap<String, Pair<String, Long>>()
    private val latest = ConcurrentHashMap<String, Pair<Pos, Long>>()
    private var poller: Thread? = null

    init {
        isReuseAddr = true
        connectionLostTimeout = 0
    }

    override fun onStart() {
        poller = Thread({ pollLoop() }, "shabekura-mc").also { it.start() }
    }

    override fun onOpen(c: WebSocket, handshake: ClientHandshake?) {
        val old = conn
        conn = c
        if (old != null && old != c) try { old.close() } catch (_: Exception) {}
        pending.clear(); latest.clear()
        onLinked(true)
        sendCommand(c, "tellraw @s {\"rawtext\":[{\"text\":\"§a[むいいむ しゃべくら] マイクラと連携したよ！\"}]}")
    }

    override fun onClose(c: WebSocket, code: Int, reason: String?, remote: Boolean) {
        if (c == conn) {
            conn = null
            latest.clear(); pending.clear()
            onLinked(false)
        }
    }

    override fun onError(c: WebSocket?, ex: Exception) {
        Log.w(TAG, "error", ex)
        if (c == null) onFail("連携用ポートを開けませんでした: ${ex.message}")
    }

    override fun onMessage(c: WebSocket, message: String) {
        try {
            val j = JSONObject(message)
            val header = j.optJSONObject("header") ?: return
            if (header.optString("messagePurpose") != "commandResponse") return
            val req = pending.remove(header.optString("requestId")) ?: return
            val body = j.optJSONObject("body") ?: return
            val pos = parse(body)
            if (pos != null) latest[req.first] = pos to System.currentTimeMillis()
            else latest.remove(req.first)
        } catch (e: Exception) {
            Log.w(TAG, "bad message", e)
        }
    }

    private fun parse(body: JSONObject): Pos? {
        if (body.optInt("statusCode", -1) != 0) return null
        var det = body.optString("details", "")
        if (det.isEmpty() || !det.trim().startsWith("[")) {
            val sm = body.optString("statusMessage", "")
            val a = sm.indexOf('[')
            val b = sm.lastIndexOf(']')
            det = if (a >= 0 && b > a) sm.substring(a, b + 1) else return null
        }
        val arr = JSONArray(det)
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        val p = o.getJSONObject("position")
        return Pos(
            p.getDouble("x"), p.getDouble("y"), p.getDouble("z"),
            o.optInt("dimension", 0), o.optDouble("yRot", 0.0)
        )
    }

    private fun sendCommand(c: WebSocket, line: String) {
        val rid = UUID.randomUUID().toString()
        val msg = JSONObject()
            .put("header", JSONObject()
                .put("version", 1)
                .put("requestId", rid)
                .put("messageType", "commandRequest")
                .put("messagePurpose", "commandRequest"))
            .put("body", JSONObject()
                .put("version", 1)
                .put("commandLine", line)
                .put("origin", JSONObject().put("type", "player")))
        try { c.send(msg.toString()) } catch (_: Exception) {}
    }

    private fun queryPosition(c: WebSocket, name: String) {
        val rid = UUID.randomUUID().toString()
        val safe = name.replace("\\", "\\\\").replace("\"", "\\\"")
        pending[rid] = name to System.currentTimeMillis()
        val msg = JSONObject()
            .put("header", JSONObject()
                .put("version", 1)
                .put("requestId", rid)
                .put("messageType", "commandRequest")
                .put("messagePurpose", "commandRequest"))
            .put("body", JSONObject()
                .put("version", 1)
                .put("commandLine", "querytarget @a[name=\"$safe\"]")
                .put("origin", JSONObject().put("type", "player")))
        try { c.send(msg.toString()) } catch (_: Exception) { pending.remove(rid) }
    }

    private fun pollLoop() {
        while (alive) {
            try { Thread.sleep(POLL_MS) } catch (_: InterruptedException) { break }
            val c = conn ?: continue
            if (!c.isOpen) continue
            val now = System.currentTimeMillis()
            pending.entries.removeIf { now - it.value.second > 3000 }
            if (pending.size < 60) {
                for (n in names().distinct()) queryPosition(c, n)
            }
            val snap = HashMap<String, Pos>()
            for ((k, v) in latest) if (now - v.second < 2000) snap[k] = v.first
            onPositions(snap)
        }
    }

    fun shutdown() {
        alive = false
        poller?.interrupt()
        try { stop(500) } catch (_: Exception) {}
    }
}
