package com.muiimu.shabekura

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** 通話中ずっと動くサービス（マイクラに切り替えても声が止まらない） */
class VoiceService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_MUTE = "mute"
        const val ACTION_DEAFEN = "deafen"
        private const val CHANNEL = "call"
        private const val NOTIF_ID = 1

        @Volatile var instance: VoiceService? = null

        fun start(ctx: Context, room: String, name: String, hostKey: String?) {
            val i = Intent(ctx, VoiceService::class.java)
                .setAction(ACTION_START)
                .putExtra("room", room)
                .putExtra("name", name)
                .putExtra("key", hostKey ?: "")
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            instance?.shutdown() ?: ctx.stopService(Intent(ctx, VoiceService::class.java))
        }

        fun serverBase(): String = BuildConfig.SERVER_URL.trim().trimEnd('/')
    }

    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var ws: WebSocket? = null
    private var audio: AudioEngine? = null
    private var bridge: McBridge? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = false
    private var room = ""
    private var name = ""
    private var hostKey = ""
    private var retry = 0

    @Volatile private var idToMember: Map<Int, Member> = emptyMap()
    @Volatile private var positions: Map<String, Pos> = emptyMap()
    @Volatile private var mcOn = false
    @Volatile private var lastPosAt = 0L
    private var lastUi = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(); return START_NOT_STICKY }
            ACTION_MUTE -> { if (running) setMuted(!AppState.muted); return START_NOT_STICKY }
            ACTION_DEAFEN -> { if (running) setDeafened(!AppState.deafened); return START_NOT_STICKY }
        }
        startForegroundCompat()
        if (running) return START_NOT_STICKY

        instance = this
        room = intent?.getStringExtra("room").orEmpty()
        name = intent?.getStringExtra("name").orEmpty()
        hostKey = intent?.getStringExtra("key").orEmpty()
        running = true

        AppState.reset()
        AppState.running = true
        AppState.roomCode = room
        AppState.myName = name
        AppState.isHost = hostKey.isNotEmpty()
        AppState.status = "接続中…"
        AppState.changed()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "shabekura:call").also { it.acquire(6 * 60 * 60 * 1000L) }

        // 部屋に入っているときだけ声を送る
        audio = AudioEngine { bytes -> if (AppState.mySlot > 0) ws?.send(bytes.toByteString()) }.also { it.start() }
        connect()

        if (AppState.isHost) {
            try {
                bridge = McBridge(
                    names = { idToMember.values.map { it.name } },
                    onPositions = { p -> sendPositions(p) },
                    onLinked = { on ->
                        AppState.bridgeOpen = on
                        if (!on) sendText(JSONObject().put("t", "mc").put("on", false))
                        AppState.changed()
                    },
                    onFail = { msg -> AppState.status = msg; AppState.changed() },
                ).also { it.start() }
            } catch (e: Exception) {
                AppState.status = "連携の準備に失敗: ${e.message}"
            }
        }
        main.post(uiTicker)
        return START_NOT_STICKY
    }

    private val uiTicker = object : Runnable {
        override fun run() {
            if (!running) return
            val t = audio?.talkingIds() ?: emptySet()
            if (t != AppState.talking) { AppState.talking = t; AppState.changed() }
            // 座標が5秒届かなければ普通の通話に戻す（サーバー側と同じ動き）
            if (mcOn && System.currentTimeMillis() - lastPosAt > 5000) {
                mcOn = false; positions = emptyMap(); recompute(force = true)
            }
            main.postDelayed(this, 250)
        }
    }

    private fun connect() {
        if (!running) return
        val base = serverBase()
        if (base.isEmpty()) {
            AppState.status = "サーバーのURLが入っていません（ビルド設定を確認）"; AppState.changed(); return
        }
        val wsBase = when {
            base.startsWith("https://") -> "wss://" + base.removePrefix("https://")
            base.startsWith("http://") -> "ws://" + base.removePrefix("http://")
            else -> "wss://$base"
        }
        val url = "$wsBase/ws?room=${enc(room)}&name=${enc(name)}&key=${enc(hostKey)}"
        val req = Request.Builder().url(url).build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (webSocket != ws) return
                retry = 0
                AppState.connected = true
                AppState.status = "通話中"
                AppState.changed()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (webSocket != ws) return
                handleText(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (webSocket != ws || bytes.size < 2) return
                val arr = bytes.toByteArray()
                audio?.onIncoming(arr[0].toInt() and 0xFF, arr, 1)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (webSocket != ws) return
                lost(code)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (webSocket != ws) return
                if (response?.code == 400) {
                    AppState.status = "ルームコードが正しくありません（英数字6文字）"
                    AppState.changed(); shutdown(keepStatus = true); return
                }
                lost(-1)
            }
        })
    }

    private fun lost(code: Int) {
        AppState.connected = false
        when (code) {
            4004 -> { AppState.status = "その通話は見つかりません（コードを確認してね）"; AppState.changed(); shutdown(keepStatus = true); return }
            4009 -> { AppState.status = "別の端末から同じ名前で入りました"; AppState.changed(); shutdown(keepStatus = true); return }
            4010 -> { AppState.status = "通話が満員です"; AppState.changed(); shutdown(keepStatus = true); return }
        }
        if (!running) return
        retry++
        val delay = minOf(10_000L, 1000L * retry)
        AppState.status = "再接続中…"
        AppState.changed()
        main.postDelayed({ connect() }, delay)
    }

    private fun handleText(text: String) {
        val m = try { JSONObject(text) } catch (_: Exception) { return }
        when (m.optString("t")) {
            "hello" -> {
                AppState.myId = m.optInt("id")
            }
            "members" -> {
                val list = m.optJSONArray("list") ?: return
                val map = HashMap<Int, Member>()
                for (i in 0 until list.length()) {
                    val o = list.getJSONObject(i)
                    map[o.getInt("id")] = Member(
                        o.getInt("id"), o.getString("name"), o.optBoolean("host"),
                        slot = o.optInt("slot", 0), out = o.optBoolean("out"),
                    )
                }
                idToMember = map
                val mine = map.values.firstOrNull { it.name == name }
                AppState.mySlot = mine?.slot ?: 0
                AppState.optOut = mine?.out ?: false
                if (m.has("mc") && !m.optBoolean("mc")) {
                    mcOn = false
                }
                audio?.retain(map.keys)
                recompute(force = true)
            }
            "pos" -> {
                val p = m.optJSONObject("p") ?: return
                val map = HashMap<String, Pos>()
                val keys = p.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val o = p.optJSONObject(k) ?: continue
                    map[k] = Pos(o.optDouble("x"), o.optDouble("y"), o.optDouble("z"), o.optInt("d"), o.optDouble("r"))
                }
                positions = map
                mcOn = true
                lastPosAt = System.currentTimeMillis()
                recompute(force = false)
            }
            "mc" -> {
                mcOn = m.optBoolean("on")
                if (!mcOn) positions = emptyMap()
                recompute(force = true)
            }
        }
    }

    /** 全員の音量・左右を計算し直す */
    private fun recompute(force: Boolean) {
        val me = positions[name]
        val iAmIn = AppState.mySlot > 0
        val list = ArrayList<Member>()
        for (mem in idToMember.values.sortedBy { if (it.slot > 0) it.slot else 100 + it.id }) {
            if (mem.name == name) {
                list.add(mem.copy(distance = if (mcOn && me != null) 0.0 else null))
                continue
            }
            val other = positions[mem.name]
            // 自分も相手も部屋に入っているときだけ、距離に応じて聞こえる
            val (g, pan) = if (mcOn && iAmIn && mem.slot > 0) Spatial.compute(me, other) else (0f to 0f)
            audio?.setSpatial(mem.id, g, pan)
            val dist = if (me != null && other != null && me.d == other.d) Spatial.distance(me, other) else null
            list.add(mem.copy(distance = dist, gain = g))
        }
        AppState.members = list
        AppState.mcLinked = mcOn
        val now = System.currentTimeMillis()
        if (force || now - lastUi > 400) {
            lastUi = now
            AppState.changed()
        }
    }

    private fun sendPositions(p: Map<String, Pos>) {
        val o = JSONObject()
        for ((k, v) in p) {
            o.put(k, JSONObject().put("x", v.x).put("y", v.y).put("z", v.z).put("d", v.d).put("r", v.r))
        }
        sendText(JSONObject().put("t", "pos").put("p", o))
    }

    private fun sendText(o: JSONObject) {
        try { ws?.send(o.toString()) } catch (_: Exception) {}
    }

    fun setMuted(m: Boolean) {
        AppState.muted = m
        audio?.muted = m
        AppState.changed()
        updateNotification()
    }

    /** スピーカーミュート: 自分の声も送らないし、相手の声も聞こえない */
    fun setDeafened(d: Boolean) {
        AppState.deafened = d
        audio?.deafened = d
        AppState.changed()
        updateNotification()
    }

    /** 「通話を抜ける」/「通話に戻る」 */
    fun setOptOut(o: Boolean) {
        AppState.optOut = o
        sendText(JSONObject().put("t", "optout").put("on", o))
        AppState.changed()
    }

    private fun updateNotification() {
        if (!running) return
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {}
    }

    fun shutdown(keepStatus: Boolean = false) {
        if (!running && instance == null) return
        running = false
        main.removeCallbacksAndMessages(null)
        try { bridge?.shutdown() } catch (_: Exception) {}
        bridge = null
        val old = ws
        ws = null
        try { old?.close(1000, "bye") } catch (_: Exception) {}
        audio?.stop(); audio = null
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        val status = AppState.status
        AppState.reset()
        AppState.status = if (keepStatus) status else "待機中"
        AppState.changed()
        instance = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) shutdown()
        super.onDestroy()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun action(req: Int, act: String, label: String): Notification.Action {
            val pi = PendingIntent.getService(
                this, req, Intent(this, VoiceService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(null, label, pi).build()
        }
        val state = when {
            AppState.deafened -> "スピーカーミュート中（話さない・聞こえない）"
            AppState.muted -> "ミュート中（聞こえるけど話さない）"
            else -> "しゃべくら 通話中"
        }
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("むいいむ通話")
            .setContentText(state)
            .setSmallIcon(R.drawable.ic_stat_call)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(action(1, ACTION_STOP, "退出"))
            .addAction(action(2, ACTION_MUTE, if (AppState.muted) "ミュート解除" else "ミュート"))
            .addAction(action(3, ACTION_DEAFEN, if (AppState.deafened) "スピーカー解除" else "スピーカーミュート"))
            .build()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "むいいむ通話", NotificationManager.IMPORTANCE_LOW))
        }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
