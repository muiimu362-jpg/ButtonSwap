package com.muiimu.shabekura

import android.os.Handler
import android.os.Looper

data class Member(
    val id: Int,
    val name: String,
    val host: Boolean,
    val distance: Double? = null,
    val gain: Float = 1f,
)

/** 画面とサービスで共有する状態 */
object AppState {
    @Volatile var running = false
    @Volatile var connected = false
    @Volatile var isHost = false
    @Volatile var muted = false
    @Volatile var mcLinked = false      // マイクラから座標が届いているか
    @Volatile var bridgeOpen = false    // (ホストのみ) マイクラが /connect してきているか
    @Volatile var roomCode = ""
    @Volatile var myName = ""
    @Volatile var myId = 0
    @Volatile var status = "待機中"
    @Volatile var members: List<Member> = emptyList()
    @Volatile var talking: Set<Int> = emptySet()
    @Volatile var selfTalking = false
    @Volatile var micLevel = 0

    private val main = Handler(Looper.getMainLooper())
    private val listeners = mutableListOf<() -> Unit>()

    fun addListener(l: () -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: () -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    fun changed() {
        val copy = synchronized(listeners) { listeners.toList() }
        main.post { copy.forEach { it() } }
    }

    fun reset() {
        running = false; connected = false; isHost = false; muted = false
        mcLinked = false; bridgeOpen = false; members = emptyList()
        talking = emptySet(); selfTalking = false; myId = 0; micLevel = 0
    }
}
