// むいいむ しゃべくら 中継サーバー (Cloudflare Workers + Durable Objects)
import { DurableObject } from "cloudflare:workers";
import { WEB_HTML, MANIFEST, ICON_SVG } from "./web.js";

// これより遠い人には音声そのものを送らない（ブロック）
const SERVER_CUTOFF = 26;
// ホストから座標が届かなくなったら、普通の通話に戻すまでの時間
const POS_TIMEOUT_MS = 5000;

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomString(chars, len) {
  const bytes = new Uint8Array(len);
  crypto.getRandomValues(bytes);
  let s = "";
  for (const b of bytes) s += chars[b % chars.length];
  return s;
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/create" && request.method === "POST") {
      let body = {};
      try {
        body = await request.json();
      } catch (_) {}
      // 通話を作れるのはパスワードを知っている人（＝むいいむ）だけ
      if (!env.OWNER_PASSWORD || body.password !== env.OWNER_PASSWORD) {
        return json({ error: "パスワードが違います" }, 403);
      }
      const code = randomString(CODE_CHARS, 6);
      const hostKey = randomString("0123456789abcdef", 32);
      const stub = env.ROOM.get(env.ROOM.idFromName(code));
      await stub.init(hostKey);
      return json({ code, hostKey });
    }

    if (url.pathname === "/ws") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("websocket only", { status: 426 });
      }
      const code = (url.searchParams.get("room") || "").toUpperCase();
      if (!/^[A-Z0-9]{6}$/.test(code)) return new Response("bad room", { status: 400 });
      const stub = env.ROOM.get(env.ROOM.idFromName(code));
      return stub.fetch(request);
    }

    if (url.pathname === "/manifest.json") {
      return new Response(MANIFEST, { headers: { "content-type": "application/manifest+json" } });
    }
    if (url.pathname === "/icon.svg") {
      return new Response(ICON_SVG, { headers: { "content-type": "image/svg+xml" } });
    }
    if (url.pathname === "/health") {
      return new Response("むいいむ しゃべくら server OK", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }
    // それ以外は Web 版（iPhone・PC 用）を返す
    return new Response(WEB_HTML, {
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  },
};

export class Room extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.positions = {}; // name -> {x,y,z,d,r}
    this.lastPosAt = 0;
    this.mcOnline = false;
  }

  async init(hostKey) {
    await this.ctx.storage.put("hostKey", hostKey);
  }

  openSockets(except) {
    return this.ctx
      .getWebSockets()
      .filter((s) => s !== except && s.readyState === 1);
  }

  async fetch(request) {
    const url = new URL(request.url);
    const hostKey = await this.ctx.storage.get("hostKey");
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.ctx.acceptWebSocket(server);

    if (!hostKey) {
      server.close(4004, "room not found");
      return new Response(null, { status: 101, webSocket: client });
    }

    const name = (url.searchParams.get("name") || "").trim().slice(0, 40);
    if (!name) {
      server.close(4001, "no name");
      return new Response(null, { status: 101, webSocket: client });
    }
    const isHost = url.searchParams.get("key") === hostKey;

    // 同じ名前で入り直したら古い接続を切る
    const used = new Set();
    for (const s of this.openSockets(server)) {
      const a = s.deserializeAttachment();
      if (!a) continue;
      if (a.name === name) {
        try { s.close(4009, "replaced"); } catch (_) {}
      } else {
        used.add(a.id);
      }
    }
    let id = 1;
    while (used.has(id) && id < 250) id++;
    if (used.size >= 249) {
      server.close(4010, "room full");
      return new Response(null, { status: 101, webSocket: client });
    }

    server.serializeAttachment({ id, name, isHost });
    server.send(JSON.stringify({ t: "hello", id, host: isHost }));
    this.broadcastMembers();
    return new Response(null, { status: 101, webSocket: client });
  }

  posActive() {
    return this.mcOnline && Date.now() - this.lastPosAt < POS_TIMEOUT_MS;
  }

  canHear(a, b) {
    if (!this.posActive()) return true; // マイクラ未連携なら普通の通話
    const pa = this.positions[a];
    const pb = this.positions[b];
    if (!pa || !pb) return false;
    if (pa.d !== pb.d) return false;
    const dx = pa.x - pb.x, dy = pa.y - pb.y, dz = pa.z - pb.z;
    return dx * dx + dy * dy + dz * dz <= SERVER_CUTOFF * SERVER_CUTOFF;
  }

  broadcastText(obj, except) {
    const msg = JSON.stringify(obj);
    for (const s of this.openSockets(except)) {
      try { s.send(msg); } catch (_) {}
    }
  }

  broadcastMembers(except) {
    const list = [];
    for (const s of this.openSockets(except)) {
      const a = s.deserializeAttachment();
      if (a) list.push({ id: a.id, name: a.name, host: a.isHost });
    }
    this.broadcastText({ t: "members", list, mc: this.posActive() }, except);
  }

  async webSocketMessage(ws, message) {
    const a = ws.deserializeAttachment();
    if (!a) return;

    if (typeof message === "string") {
      let m;
      try { m = JSON.parse(message); } catch (_) { return; }
      if (m.t === "pos" && a.isHost && m.p && typeof m.p === "object") {
        this.positions = m.p;
        this.lastPosAt = Date.now();
        this.mcOnline = true;
        this.broadcastText({ t: "pos", p: m.p });
      } else if (m.t === "mc" && a.isHost) {
        this.mcOnline = !!m.on;
        if (!m.on) this.positions = {};
        this.broadcastText({ t: "mc", on: !!m.on });
      } else if (m.t === "ping") {
        ws.send(JSON.stringify({ t: "pong" }));
      }
      return;
    }

    // 音声フレーム: 先頭1バイトに話している人のIDを付けて、聞こえる範囲の人にだけ送る
    const data = new Uint8Array(message);
    if (data.length === 0 || data.length > 4000) return;
    const out = new Uint8Array(data.length + 1);
    out[0] = a.id;
    out.set(data, 1);
    for (const s of this.openSockets(ws)) {
      const b = s.deserializeAttachment();
      if (!b) continue;
      if (this.canHear(a.name, b.name)) {
        try { s.send(out); } catch (_) {}
      }
    }
  }

  async webSocketClose(ws, code, reason) {
    try { ws.close(code, reason); } catch (_) {}
    this.broadcastMembers(ws);
  }

  async webSocketError(ws) {
    this.broadcastMembers(ws);
  }
}
