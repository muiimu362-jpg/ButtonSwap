package com.muiimu.buttonswap;

// Shizuku の権限（ADB と同じ）で動く小さなサービス
interface IShellService {
    // Shizuku が決めている「終了」用の番号
    void destroy() = 16777114;

    // コマンドを動かして出力を返す
    String run(String cmd, int timeoutSec) = 1;

    // 振り向き感度を動かす（成功なら空文字、失敗なら理由）
    //  axisPairs : [ABSコード, Androidの軸, ...]
    //  ranges    : [ABSコード, min, max, flat, 今の値, ...]
    //  deadzone  : 右スティックのデッドゾーン（%）
    //  keyPairs  : [生のボタン番号, Androidのボタン, ...]
    String startStick(String node, int deviceId, in int[] axisPairs, in int[] ranges,
                      int rightX, int rightY, in int[] keyPairs, int mode, float mult, int deadzone) = 3;

    // 動作中に感度だけ変える
    void setStick(int mode, float mult, int deadzone) = 4;

    // 止めてコントローラーを元に戻す
    void stopStick() = 5;

    // 今の状態（動作中なら空文字、止まっていれば理由）
    String stickError() = 6;

    boolean stickRunning() = 7;
}
