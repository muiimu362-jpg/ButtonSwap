package com.muiimu.buttonswap;

// Shizuku の権限（ADB と同じ）で動く小さなサービス
interface IShellService {
    // Shizuku が決めている「終了」用の番号
    void destroy() = 16777114;

    // コマンドを動かして出力を返す
    String run(String cmd, int timeoutSec) = 1;

    // ファイル（/dev/input/eventX など）を読み取り用に開いて渡す
    ParcelFileDescriptor open(String path) = 2;
}
