package com.muiimu.buttonswap

import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent

/**
 * 【実験】スティック感度を変える仕組みが、このスマホで使えるかを調べる。
 *
 * 本番でやりたいこと：
 *   1. コントローラーの生の入力（/dev/input）を Shizuku の権限で読む
 *   2. コントローラーを Android から一時的に切り離す（二重入力を防ぐ）
 *   3. スティックの値を変えて、ゲームに送り直す
 * それぞれができるかを確認して、結果を文字で返す。
 */
object Probe {

    fun run(log: (String) -> Unit) {
        // ── 0. 準備 ──
        if (!Injector.ready()) {
            log("❌ Shizuku が使えません（起動して許可してください）")
            return
        }
        log("✅ Shizuku OK")

        val pad = findController()
        if (pad == null) {
            log("❌ コントローラーが見つかりません（つないでからもう一度）")
            return
        }
        log("✅ コントローラー: ${pad.name}（id=${pad.id}）")
        val axes = pad.motionRanges.map { MotionEvent.axisToString(it.axis).removePrefix("AXIS_") }.distinct()
        log("　スティックの軸: ${axes.joinToString(", ")}")

        // ── 1. 生の入力を読めるか ──
        val list = Shell.run("getevent -pl", 4)
        if (list == null) {
            log("❌ 1. Shizuku でコマンドを動かせません")
            return
        }
        val node = Shell.findNode(list, pad.name)
        if (node == null) {
            log("❌ 1. コントローラーの生データの場所が見つかりません")
            log("　（getevent の出力先頭）\n" + list.lines().take(12).joinToString("\n"))
            return
        }
        log("✅ 1a. 生データの場所: $node")

        log("　→ 今から 3 秒間、右スティックをぐるぐる回してください…")
        SystemClock.sleep(500)
        val events = Shell.run("timeout 3 getevent -l $node", 6) ?: ""
        val absLines = events.lines().filter { it.contains("EV_ABS") }
        val absCodes = absLines.mapNotNull { Regex("EV_ABS\\s+(\\S+)").find(it)?.groupValues?.get(1) }.distinct()
        if (absLines.isEmpty()) {
            log("❌ 1b. スティックの動きを読めませんでした")
        } else {
            log("✅ 1b. スティックの動きを ${absLines.size} 件読めました（${absCodes.joinToString(", ")}）")
        }

        // ── 2. 一時的に切り離せるか ──
        var disabled = false
        try {
            Injector.callInputManager("disableInputDevice", pad.id)
            disabled = true
            SystemClock.sleep(300)
            log("✅ 2. コントローラーを一時的に切り離せました")
        } catch (t: Throwable) {
            val c = t.cause ?: t
            log("❌ 2. 切り離せません: ${c.javaClass.simpleName}: ${c.message}")
        } finally {
            if (disabled) {
                try {
                    Injector.callInputManager("enableInputDevice", pad.id)
                    log("　（すぐに元に戻しました）")
                } catch (t: Throwable) {
                    log("⚠ 元に戻せませんでした。コントローラーをつなぎ直してください")
                }
            }
        }

        // ── 3. スティックの動きを送れるか ──
        try {
            val now = SystemClock.uptimeMillis()
            val props = arrayOf(MotionEvent.PointerProperties().apply {
                id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN
            })
            val coords = arrayOf(MotionEvent.PointerCoords().apply {
                setAxisValue(MotionEvent.AXIS_Z, 0f)
                setAxisValue(MotionEvent.AXIS_RZ, 0f)
            })
            val ev = MotionEvent.obtain(
                now, now, MotionEvent.ACTION_MOVE, 1, props, coords,
                0, 0, 1f, 1f, pad.id, 0, InputDevice.SOURCE_JOYSTICK, 0
            )
            Injector.injectNow(ev)
            ev.recycle()
            log("✅ 3. スティックの動きを送れました")
        } catch (t: Throwable) {
            val c = t.cause ?: t
            log("❌ 3. 送れません: ${c.javaClass.simpleName}: ${c.message}")
        }

        log("\n調査おわり。この画面のスクショを送ってください。")
    }

    private fun findController(): InputDevice? {
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            if ((d.sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) return d
        }
        return null
    }
}
