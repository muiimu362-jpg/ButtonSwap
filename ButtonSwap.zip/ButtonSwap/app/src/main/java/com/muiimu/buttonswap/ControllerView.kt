package com.muiimu.buttonswap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

/**
 * コントローラーの絵。ボタンをタップすると onButtonTap が呼ばれる。
 * 設定を変えたボタンはオレンジ、連射は黄色の枠と ⚡、実際に押されたボタンは水色に光る。
 */
class ControllerView(context: Context) : View(context) {

    var onButtonTap: ((Int) -> Unit)? = null
    var configs: Map<Int, ButtonConfig> = emptyMap()
        set(v) { field = v; invalidate() }

    private var pressedCode: Int? = null
    private val clearPressed = Runnable { pressedCode = null; invalidate() }

    // 1000 x 640 の座標で設計して、画面幅に合わせて拡大縮小する
    private enum class Shape { CIRCLE, RECT }
    private data class Btn(val code: Int, val shape: Shape, val box: RectF)

    private fun circle(code: Int, cx: Float, cy: Float, r: Float) =
        Btn(code, Shape.CIRCLE, RectF(cx - r, cy - r, cx + r, cy + r))
    private fun rect(code: Int, l: Float, t: Float, r: Float, b: Float) =
        Btn(code, Shape.RECT, RectF(l, t, r, b))

    private val buttons = listOf(
        rect(KeyEvent.KEYCODE_BUTTON_L2, 140f, 10f, 340f, 70f),
        rect(KeyEvent.KEYCODE_BUTTON_L1, 140f, 85f, 340f, 135f),
        rect(KeyEvent.KEYCODE_BUTTON_R2, 660f, 10f, 860f, 70f),
        rect(KeyEvent.KEYCODE_BUTTON_R1, 660f, 85f, 860f, 135f),
        circle(KeyEvent.KEYCODE_BUTTON_SELECT, 420f, 230f, 26f),
        circle(KeyEvent.KEYCODE_BUTTON_START, 580f, 230f, 26f),
        circle(KeyEvent.KEYCODE_BUTTON_THUMBL, 270f, 320f, 62f),
        circle(KeyEvent.KEYCODE_BUTTON_THUMBR, 640f, 470f, 58f),
        rect(KeyEvent.KEYCODE_DPAD_UP, 335f, 400f, 385f, 450f),
        rect(KeyEvent.KEYCODE_DPAD_DOWN, 335f, 500f, 385f, 550f),
        rect(KeyEvent.KEYCODE_DPAD_LEFT, 285f, 450f, 335f, 500f),
        rect(KeyEvent.KEYCODE_DPAD_RIGHT, 385f, 450f, 435f, 500f),
    )

    /** ABXY は種類によって位置が変わるので毎回作る */
    private fun faceButtons(): List<Btn> {
        val pos = arrayOf(740f to 255f, 805f to 320f, 740f to 385f, 675f to 320f) // 上・右・下・左
        return listOf(
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
        ).map { code ->
            val (x, y) = pos[Pad.facePos(code)]
            circle(code, x, y, 36f)
        }
    }

    private fun allButtons() = buttons + faceButtons()

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#37474F") }
    private val btnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 8f; color = Color.parseColor("#FFD600")
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFAB40"); textAlign = Paint.Align.CENTER; isFakeBoldText = true
        textSize = 30f
    }

    /** 実機のボタンが押されたときに一瞬光らせる */
    fun flash(code: Int) {
        pressedCode = code
        removeCallbacks(clearPressed)
        postDelayed(clearPressed, 350)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 0.64f).toInt())
    }

    private val scale get() = width / 1000f

    override fun onDraw(canvas: Canvas) {
        canvas.save()
        canvas.scale(scale, scale)

        // 本体（左右のグリップ＋胴体）
        canvas.drawOval(RectF(110f, 280f, 380f, 630f), bodyPaint)
        canvas.drawOval(RectF(620f, 280f, 890f, 630f), bodyPaint)
        canvas.drawRoundRect(RectF(110f, 145f, 890f, 560f), 160f, 160f, bodyPaint)

        for (b in allButtons()) {
            val cfg = configs[b.code]
            btnPaint.color = when {
                pressedCode == b.code -> Color.parseColor("#40C4FF")
                cfg?.target != null -> Color.parseColor("#FF6D00")
                else -> Color.parseColor("#212121")
            }
            when (b.shape) {
                Shape.CIRCLE -> canvas.drawOval(b.box, btnPaint)
                Shape.RECT -> canvas.drawRoundRect(b.box, 14f, 14f, btnPaint)
            }
            if (cfg?.turbo == true) {
                when (b.shape) {
                    Shape.CIRCLE -> canvas.drawOval(b.box, ringPaint)
                    Shape.RECT -> canvas.drawRoundRect(b.box, 14f, 14f, ringPaint)
                }
            }

            // ボタン名
            val name = Mapping.nameOf(b.code)
            textPaint.textSize = if (b.box.height() < 60f) 30f else 38f
            canvas.drawText(name, b.box.centerX(), b.box.centerY() + textPaint.textSize / 3f, textPaint)

            // 変更内容（→B / ⚡）をボタンの下に小さく
            val notes = buildList {
                cfg?.target?.let { add("→" + Mapping.nameOf(it)) }
                if (cfg?.turbo == true) add("⚡")
            }
            if (notes.isNotEmpty()) {
                canvas.drawText(notes.joinToString(" "), b.box.centerX(), b.box.bottom + 32f, subPaint)
            }
        }
        canvas.restore()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val x = e.x / scale
            val y = e.y / scale
            // 小さいボタンも押しやすいように当たり判定を少し広げる
            val hit = allButtons().firstOrNull { RectF(it.box).apply { inset(-14f, -14f) }.contains(x, y) }
            hit?.let { onButtonTap?.invoke(it.code) }
        }
        return true
    }
}
