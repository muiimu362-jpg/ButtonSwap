package com.muiimu.buttonswap

import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.view.InputEvent
import android.view.KeyEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors

/**
 * Shizuku（ADB 相当の権限）経由で InputManager.injectInputEvent を呼び、
 * 別のボタンとしてキー入力を送り直す。
 */
object Injector {
    private const val TAG = "ButtonSwap"
    private const val INJECT_MODE_ASYNC = 0
    private const val PENDING_TIMEOUT_MS = 1000L

    private val executor = Executors.newSingleThreadExecutor()

    /** 自分で送り直した入力の記録（ユーザー補助に戻ってきたときに再変換しないため） */
    private data class Pending(val code: Int, val action: Int, val at: Long)
    private val pending = ConcurrentLinkedQueue<Pending>()

    @Volatile private var inputManager: Any? = null
    @Volatile private var injectMethod: Method? = null

    fun shizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        shizukuRunning() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    fun ready(): Boolean = hasPermission()

    /** 自分で送り直した入力なら true（記録を 1 件消費する） */
    fun consumeIfInjected(e: KeyEvent): Boolean {
        val now = SystemClock.uptimeMillis()
        pending.removeIf { now - it.at > PENDING_TIMEOUT_MS }
        val hit = pending.firstOrNull { it.code == e.keyCode && it.action == e.action } ?: return false
        return pending.remove(hit)
    }

    /** src の押した/離したタイミングをそのまま使い、キーコードだけ target に変えて送る */
    fun inject(src: KeyEvent, target: Int) {
        val ev = KeyEvent(
            src.downTime, src.eventTime, src.action, target, src.repeatCount,
            src.metaState, src.deviceId, 0, src.flags, src.source
        )
        val mark = Pending(target, src.action, SystemClock.uptimeMillis())
        pending.add(mark)
        executor.execute {
            try {
                ensureInputManager()
                injectMethod!!.invoke(inputManager, ev, INJECT_MODE_ASYNC)
            } catch (t: Throwable) {
                pending.remove(mark)
                Log.e(TAG, "inject failed", t)
                val cause = (t.cause ?: t)
                Diag.result("❌ 送り直しに失敗: ${cause.javaClass.simpleName}: ${cause.message}")
                inputManager = null
                injectMethod = null
            }
        }
    }

    /** 連射用：今の時刻で新しく「押す」「離す」を作って送る */
    fun injectFresh(code: Int, action: Int, downTime: Long, deviceId: Int, source: Int) {
        val now = SystemClock.uptimeMillis()
        val ev = KeyEvent(downTime, now, action, code, 0, 0, deviceId, 0, 0, source)
        val mark = Pending(code, action, now)
        pending.add(mark)
        executor.execute {
            try {
                ensureInputManager()
                injectMethod!!.invoke(inputManager, ev, INJECT_MODE_ASYNC)
            } catch (t: Throwable) {
                pending.remove(mark)
                Log.e(TAG, "inject failed", t)
                val cause = (t.cause ?: t)
                Diag.result("❌ 送り直しに失敗: ${cause.javaClass.simpleName}: ${cause.message}")
                inputManager = null
                injectMethod = null
            }
        }
    }

    private fun ensureInputManager() {
        if (inputManager != null && injectMethod != null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            HiddenApiBypass.addHiddenApiExemptions("L")
        }
        val binder: IBinder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
        val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
        val im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
        injectMethod = im.javaClass.getMethod(
            "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
        )
        inputManager = im
    }
}
