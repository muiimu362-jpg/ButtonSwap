package com.muiimu.buttonswap

import android.content.Context
import android.view.KeyEvent

/**
 * コントローラーの「生のボタン番号（scanCode）」→「Android のボタン（keyCode）」の対応表。
 * 普段コントローラーを使っている間に自動で覚える。覚えていないものは一般的な対応を使う。
 */
object ScanMap {
    private const val PREFS = "scanmap"
    @Volatile private var cache: HashMap<Int, Int>? = null

    /** Linux の一般的なゲームパッドのボタン番号 → Android のボタン */
    private val GENERIC = mapOf(
        0x130 to KeyEvent.KEYCODE_BUTTON_A,
        0x131 to KeyEvent.KEYCODE_BUTTON_B,
        0x132 to KeyEvent.KEYCODE_BUTTON_C,
        0x133 to KeyEvent.KEYCODE_BUTTON_X,
        0x134 to KeyEvent.KEYCODE_BUTTON_Y,
        0x135 to KeyEvent.KEYCODE_BUTTON_Z,
        0x136 to KeyEvent.KEYCODE_BUTTON_L1,
        0x137 to KeyEvent.KEYCODE_BUTTON_R1,
        0x138 to KeyEvent.KEYCODE_BUTTON_L2,
        0x139 to KeyEvent.KEYCODE_BUTTON_R2,
        0x13a to KeyEvent.KEYCODE_BUTTON_SELECT,
        0x13b to KeyEvent.KEYCODE_BUTTON_START,
        0x13c to KeyEvent.KEYCODE_BUTTON_MODE,
        0x13d to KeyEvent.KEYCODE_BUTTON_THUMBL,
        0x13e to KeyEvent.KEYCODE_BUTTON_THUMBR,
        0x220 to KeyEvent.KEYCODE_DPAD_UP,
        0x221 to KeyEvent.KEYCODE_DPAD_DOWN,
        0x222 to KeyEvent.KEYCODE_DPAD_LEFT,
        0x223 to KeyEvent.KEYCODE_DPAD_RIGHT,
    )

    private fun load(ctx: Context): HashMap<Int, Int> {
        cache?.let { return it }
        val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val m = HashMap<Int, Int>()
        for ((k, v) in sp.all) {
            if (v is Int) k.toIntOrNull()?.let { m[it] = v }
        }
        cache = m
        return m
    }

    fun learn(ctx: Context, scan: Int, key: Int) {
        if (scan <= 0) return
        val m = load(ctx)
        if (m[scan] == key) return
        m[scan] = key
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(scan.toString(), key).apply()
    }

    fun keyFor(ctx: Context, scan: Int): Int? = load(ctx)[scan] ?: GENERIC[scan]
}
