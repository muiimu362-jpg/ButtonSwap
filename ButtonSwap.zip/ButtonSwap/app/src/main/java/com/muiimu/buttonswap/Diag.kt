package com.muiimu.buttonswap

import android.os.Handler
import android.os.Looper

/** 動かないときの原因を画面に出すための記録 */
object Diag {
    @Volatile var serviceConnected = false
    @Volatile var lastReceived: String = "まだ何も受け取っていません"
    @Volatile var lastResult: String = "-"
    @Volatile var stickStatus: String = "停止中"

    var onChange: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun received(s: String) { lastReceived = s; notifyUi() }
    fun result(s: String) { lastResult = s; notifyUi() }
    fun stick(s: String) { stickStatus = s; notifyUi() }
    fun connected(on: Boolean) { serviceConnected = on; notifyUi() }

    private fun notifyUi() { main.post { onChange?.invoke() } }
}
