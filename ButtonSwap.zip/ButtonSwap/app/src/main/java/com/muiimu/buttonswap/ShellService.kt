package com.muiimu.buttonswap

import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/**
 * Shizuku の UserService として、Shizuku の権限（ADB と同じ）で動くサービス。
 * このクラスは別のプロセスで動くので、アプリの他の部分（画面など）には触らない。
 * ※ ここで例外を外に投げるとサービスごと落ちるので、全部ここで受け止める。
 */
class ShellService : IShellService.Stub() {

    @Volatile private var stick: StickCore? = null

    override fun destroy() {
        try { stick?.stop() } catch (t: Throwable) {}
        exitProcess(0)
    }

    override fun run(cmd: String, timeoutSec: Int): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val out = StringBuilder()
        val reader = Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { synchronized(out) { out.appendLine(it) } }
            } catch (e: Throwable) {
            }
        }.apply { start() }
        if (!p.waitFor(timeoutSec.toLong(), TimeUnit.SECONDS)) p.destroy()
        reader.join(500)
        synchronized(out) { out.toString() }
    } catch (t: Throwable) {
        "ERROR ${t.javaClass.simpleName}: ${t.message}"
    }

    override fun startStick(
        node: String, deviceId: Int, axisPairs: IntArray, ranges: IntArray,
        rightX: Int, rightY: Int, keyPairs: IntArray, mode: Int, mult: Float, deadzone: Int,
    ): String = try {
        stick?.stop()
        val core = StickCore(node, deviceId, axisPairs, ranges, rightX, rightY, keyPairs, mode, mult, deadzone / 100f)
        val err = core.start()
        stick = if (err.isEmpty()) core else null
        err
    } catch (t: Throwable) {
        "${t.javaClass.simpleName}: ${t.message}"
    }

    override fun setStick(mode: Int, mult: Float, deadzone: Int) {
        stick?.let { it.mode = mode; it.mult = mult; it.deadzone = deadzone / 100f }
    }

    override fun stopStick() {
        try { stick?.stop() } catch (t: Throwable) {}
        stick = null
    }

    override fun stickError(): String = stick?.error ?: ""

    override fun stickRunning(): Boolean = stick?.running == true
}
