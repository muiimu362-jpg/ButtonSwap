package com.muiimu.buttonswap

import android.os.ParcelFileDescriptor
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/**
 * Shizuku の UserService として、Shizuku の権限（ADB と同じ）で動くサービス。
 * このクラスは別のプロセスで動くので、アプリの他の部分（画面など）には触らない。
 */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun run(cmd: String, timeoutSec: Int): String {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val out = StringBuilder()
        val reader = Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { synchronized(out) { out.appendLine(it) } }
            } catch (e: Throwable) {
            }
        }.apply { start() }
        if (!p.waitFor(timeoutSec.toLong(), TimeUnit.SECONDS)) p.destroy()
        reader.join(500)
        return synchronized(out) { out.toString() }
    }

    override fun open(path: String): ParcelFileDescriptor =
        ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
}
