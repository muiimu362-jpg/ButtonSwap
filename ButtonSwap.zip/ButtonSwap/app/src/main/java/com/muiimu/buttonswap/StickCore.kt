package com.muiimu.buttonswap

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow

/**
 * 振り向き感度の本体。ShellService の中（Shizuku の権限のプロセス）で動く。
 *
 * コントローラーの入力は横取りしない（ボタンも左スティックも、今まで通りそのままゲームに届く）。
 * 右スティックの傾きを「読むだけ」にして、倒している分だけマウスの動きを上乗せして速く回す。
 *
 * ※ このクラスはアプリとは別のプロセスで動くので、画面や設定ファイルには触らない。
 */
class StickCore(
    private val node: String,
    private val deviceId: Int,
    axisPairs: IntArray,
    rangeData: IntArray,
    private val rightX: Int,
    private val rightY: Int,
    @Suppress("UNUSED_PARAMETER") keyPairs: IntArray,
    @Volatile var mode: Int,
    @Volatile var mult: Float,
    @Volatile var deadzone: Float,
) {
    /** 右スティックの横・縦にあたる生データの番号 */
    private var codeX = -1
    private var codeY = -1
    private val ranges = HashMap<Int, IntArray>()   // ABS コード → min, max, flat, 真ん中
    private val raw = HashMap<Int, Int>()

    @Volatile var running = false
        private set
    @Volatile var error = ""
        private set

    private var input: FileInputStream? = null
    private lateinit var im: Any
    private lateinit var inject: Method

    @Volatile private var mouseX = 0f
    @Volatile private var mouseY = 0f

    init {
        var i = 0
        while (i + 1 < axisPairs.size) {
            if (axisPairs[i + 1] == rightX) codeX = axisPairs[i]
            if (axisPairs[i + 1] == rightY) codeY = axisPairs[i]
            i += 2
        }
        i = 0
        while (i + 4 < rangeData.size) {
            val min = rangeData[i + 1]
            val max = rangeData[i + 2]
            val now = rangeData[i + 4]
            // 起動したときの位置を「真ん中」として覚える（触っていないはずなので）。
            // ただし、大きくずれていたら触っていたとみなして、範囲のまん中を使う
            val mid = (min + max) / 2
            val half = (max - min) / 2
            val center = if (abs(now - mid) < half / 4) now else mid
            ranges[rangeData[i]] = intArrayOf(min, max, rangeData[i + 3], center)
            i += 5
        }
    }

    /** 始める。失敗したら理由を返す */
    fun start(): String {
        if (codeX < 0 || codeY < 0) return "右スティックが見つかりません"
        try {
            val binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            im = Class.forName("android.hardware.input.IInputManager\$Stub")
                .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
            inject = im.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (t: Throwable) {
            return "InputManager を使えません: ${desc(t)}"
        }

        // 読むだけ（横取りはしない）
        try {
            input = FileInputStream(File(node))
        } catch (t: Throwable) {
            return "生データを開けません: ${desc(t)}"
        }

        running = true
        error = ""
        Thread({ readLoop() }, "stick-core").start()
        Thread({ mouseLoop() }, "stick-mouse").start()
        return ""
    }

    fun stop() {
        if (!running) return
        running = false
        mouseX = 0f
        mouseY = 0f
        try { input?.close() } catch (t: Throwable) {}
    }

    // ───── 右スティックの傾きを読む ─────

    private fun readLoop() {
        val size = if (android.os.Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) 24 else 16
        val buf = ByteArray(size)
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        var dirty = false
        try {
            val ins = DataInputStream(input!!)
            while (running) {
                ins.readFully(buf)
                val type = bb.getShort(size - 8).toInt() and 0xffff
                val code = bb.getShort(size - 6).toInt() and 0xffff
                val value = bb.getInt(size - 4)
                when (type) {
                    3 -> if (code == codeX || code == codeY) { raw[code] = value; dirty = true } // EV_ABS
                    0 -> if (code == 0 && dirty) { update(); dirty = false }                      // EV_SYN
                }
            }
        } catch (t: Throwable) {
            if (running) error = "読み取りが止まりました: ${desc(t)}"
        }
        if (running) {
            // コントローラーが切れたなど
            running = false
            mouseX = 0f
            mouseY = 0f
            try { input?.close() } catch (t: Throwable) {}
        }
    }

    /** 右スティックの傾きから、上乗せするマウスの動きの向きと強さを決める */
    private fun update() {
        var x = axis(codeX)
        var y = axis(codeY)
        var len = hypot(x, y)

        // デッドゾーン（ドリフト防止）
        val dz = deadzone.coerceIn(0f, 0.9f)
        if (len <= dz) {
            mouseX = 0f
            mouseY = 0f
            return
        }
        // デッドゾーンの外側を 0〜1 に引き伸ばす（ゆっくり動かし始められるように）
        val k = ((len - dz) / (1f - dz)) / len
        x *= k; y *= k; len = hypot(x, y)

        // 強さのカーブ
        val strength = when (mode) {
            1 -> len.pow(0.5f)   // PC版：少し倒しただけで一気に速くなる
            else -> len          // 普通：倒した分だけ
        }.coerceAtMost(1f)
        mouseX = x / len * strength
        mouseY = y / len * strength
    }

    private fun axis(code: Int): Float {
        val v = raw[code] ?: return 0f
        val r = ranges[code] ?: return 0f
        val min = r[0].toFloat()
        val max = r[1].toFloat()
        val center = r[3].toFloat()
        val side = if (v >= center) (max - center) else (center - min)
        if (side <= 0f) return 0f
        return ((v - center) / side).coerceIn(-1f, 1f)
    }

    // ───── マウスの動きを上乗せする ─────

    private val mouseProps = arrayOf(MotionEvent.PointerProperties().apply {
        id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE
    })

    /** 右スティックを倒している間、8ms ごとにマウスの動きを送り続ける */
    private fun mouseLoop() {
        var last = SystemClock.uptimeMillis()
        var restX = 0f
        var restY = 0f
        while (running) {
            SystemClock.sleep(8)
            val now = SystemClock.uptimeMillis()
            val dt = (now - last) / 1000f
            last = now
            val x = mouseX
            val y = mouseY
            if (x == 0f && y == 0f) { restX = 0f; restY = 0f; continue }
            // 1 倍で、全開のとき 1 秒に 600 ピクセル分マウスを動かす（50 倍なら 30000）
            val speed = 600f * mult
            restX += x * speed * dt
            restY += y * speed * dt
            val dx = restX.toInt().toFloat()
            val dy = restY.toInt().toFloat()
            restX -= dx
            restY -= dy
            if (dx == 0f && dy == 0f) continue
            val c = MotionEvent.PointerCoords().apply {
                this.x = dx
                this.y = dy
                setAxisValue(MotionEvent.AXIS_RELATIVE_X, dx)
                setAxisValue(MotionEvent.AXIS_RELATIVE_Y, dy)
            }
            val ev = MotionEvent.obtain(
                now, now, MotionEvent.ACTION_MOVE, 1, mouseProps, arrayOf(c),
                0, 0, 1f, 1f, -1, 0, InputDevice.SOURCE_MOUSE_RELATIVE, 0
            )
            try {
                inject.invoke(im, ev, 0)
            } catch (t: Throwable) {
                error = "マウスの動きを送れません: ${desc(t)}"
            } finally {
                ev.recycle()
            }
        }
    }

    private fun desc(t: Throwable): String {
        val c = if (t is java.lang.reflect.InvocationTargetException) (t.cause ?: t) else t
        return "${c.javaClass.simpleName}: ${c.message}"
    }
}
