package com.muiimu.buttonswap

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sign

/**
 * 振り向き感度の本体。ShellService の中（Shizuku の権限のプロセス）で動く。
 *
 * コントローラーの生データを独り占めして（元の入力はゲームに届かなくなる）、
 * 右スティックの値を変えてから、スティックとボタンをゲームに送り直す。
 * 独り占めはファイルを閉じれば自動で解除されるので、このプロセスが落ちても元に戻る。
 *
 * モード  0=普通 / 1=PC版 / 2=超高速（右スティックをマウスの動きに変える）
 *
 * ※ このクラスはアプリとは別のプロセスで動くので、画面や設定ファイルには触らない。
 */
class StickCore(
    private val node: String,
    private val deviceId: Int,
    axisPairs: IntArray,
    rangeData: IntArray,
    private val rightX: Int,
    private val rightY: Int,
    keyPairs: IntArray,
    @Volatile var mode: Int,
    @Volatile var mult: Float,
    @Volatile var deadzone: Float,
) {
    private val axisMap = HashMap<Int, MutableList<Int>>()     // ABS コード → Android の軸
    private val ranges = HashMap<Int, IntArray>()              // ABS コード → min, max, flat, 真ん中
    private val keyMap = HashMap<Int, Int>()                   // 生のボタン番号 → Android のボタン
    private val raw = HashMap<Int, Int>()
    private val keyDown = ConcurrentHashMap<Int, Long>()

    @Volatile var running = false
        private set
    @Volatile var error = ""
        private set

    private var input: FileInputStream? = null
    private lateinit var im: Any
    private lateinit var inject: Method

    @Volatile private var mouseX = 0f
    @Volatile private var mouseY = 0f

    init {
        var i = 0
        while (i + 1 < axisPairs.size) { axisMap.getOrPut(axisPairs[i]) { mutableListOf() }.add(axisPairs[i + 1]); i += 2 }
        i = 0
        while (i + 4 < rangeData.size) {
            val min = rangeData[i + 1]
            val max = rangeData[i + 2]
            val now = rangeData[i + 4]
            // 起動したときの位置を「真ん中」として覚える（触っていないはずなので）。
            // ただし、大きくずれていたら触っていたとみなして、範囲のまん中を使う
            val mid = (min + max) / 2
            val half = (max - min) / 2
            val center = if (abs(now - mid) < half / 4) now else mid
            ranges[rangeData[i]] = intArrayOf(min, max, rangeData[i + 3], center)
            i += 5
        }
        i = 0
        while (i + 1 < keyPairs.size) { keyMap[keyPairs[i]] = keyPairs[i + 1]; i += 2 }
    }

    /** 始める。失敗したら理由を返す */
    fun start(): String {
        try {
            val binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            im = Class.forName("android.hardware.input.IInputManager\$Stub")
                .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
            inject = im.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (t: Throwable) {
            return "InputManager を使えません: ${desc(t)}"
        }

        try {
            input = FileInputStream(File(node))
        } catch (t: Throwable) {
            return "生データを開けません: ${desc(t)}"
        }

        // 独り占めする（元の入力がゲームに二重に届かないように）
        try {
            grab(input!!.fd)
        } catch (t: Throwable) {
            try { input?.close() } catch (e: Throwable) {}
            return "コントローラーを独り占めできません: ${desc(t)}"
        }

        running = true
        error = ""
        Thread({ readLoop() }, "stick-core").start()
        Thread({ mouseLoop() }, "stick-mouse").start()
        return ""
    }

    fun stop() {
        if (!running) return
        running = false
        mouseX = 0f
        mouseY = 0f
        releaseAllKeys()
        // 閉じると独り占めが解除されて、コントローラーが Android に戻る
        try { input?.close() } catch (t: Throwable) {}
    }

    /** EVIOCGRAB：この入力デバイスを独り占めする */
    private fun grab(fd: java.io.FileDescriptor) {
        val evIocGrab = 0x40044590
        val os = Class.forName("android.system.Os")
        val m2 = os.methods.firstOrNull { it.name == "ioctlInt" && it.parameterTypes.size == 2 }
        if (m2 != null) {
            m2.invoke(null, fd, evIocGrab)
            return
        }
        val m3 = os.methods.firstOrNull { it.name == "ioctlInt" && it.parameterTypes.size == 3 }
            ?: throw NoSuchMethodException("ioctlInt")
        val ref = Class.forName("android.system.Int32Ref")
            .getConstructor(Int::class.javaPrimitiveType).newInstance(1)
        m3.invoke(null, fd, evIocGrab, ref)
    }

    private fun send(ev: InputEvent) {
        inject.invoke(im, ev, 0)
    }

    // ───── 生データを読んで送り直す ─────

    private fun readLoop() {
        val size = if (android.os.Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) 24 else 16
        val buf = ByteArray(size)
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        var dirty = false
        try {
            val ins = DataInputStream(input!!)
            while (running) {
                ins.readFully(buf)
                val type = bb.getShort(size - 8).toInt() and 0xffff
                val code = bb.getShort(size - 6).toInt() and 0xffff
                val value = bb.getInt(size - 4)
                when (type) {
                    3 -> { raw[code] = value; dirty = true }                        // EV_ABS
                    1 -> handleKey(code, value)                                      // EV_KEY
                    0 -> if (code == 0 && dirty) { emitMotion(); dirty = false }     // EV_SYN
                }
            }
        } catch (t: Throwable) {
            if (running) error = "読み取りが止まりました: ${desc(t)}"
        }
        if (running) {
            // コントローラーが切れたなど
            running = false
            mouseX = 0f
            mouseY = 0f
            releaseAllKeys()
            try { input?.close() } catch (t: Throwable) {}
        }
    }

    // ───── ボタン：押した・離したをそのまま 1 回ずつ送る ─────

    private fun handleKey(scan: Int, value: Int) {
        if (value == 2) return // 長押しのリピートは送らない
        val key = keyMap[scan] ?: return
        val now = SystemClock.uptimeMillis()
        if (value == 1) {
            if (keyDown.containsKey(key)) return // もう押している扱いなら二重に押さない
            keyDown[key] = now
            safeSend(keyEvent(now, KeyEvent.ACTION_DOWN, key, scan))
        } else {
            val down = keyDown.remove(key) ?: return // 押していないボタンは離さない
            safeSend(keyEvent(down, KeyEvent.ACTION_UP, key, scan))
        }
    }

    private fun releaseAllKeys() {
        for ((key, down) in keyDown) safeSend(keyEvent(down, KeyEvent.ACTION_UP, key, 0))
        keyDown.clear()
    }

    private fun safeSend(ev: InputEvent) {
        try { send(ev) } catch (t: Throwable) {}
    }

    private fun keyEvent(down: Long, action: Int, key: Int, scan: Int): KeyEvent {
        var src = InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_KEYBOARD
        if (key in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT) src = src or InputDevice.SOURCE_DPAD
        // scanCode は本物と同じ（ボタン入れ替えの設定がそのまま効くように）
        return KeyEvent(down, SystemClock.uptimeMillis(), action, key, 0, 0, deviceId, scan, 0, src)
    }

    // ───── スティック ─────

    private val props = arrayOf(MotionEvent.PointerProperties().apply {
        id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN
    })

    private fun emitMotion() {
        val c = MotionEvent.PointerCoords()
        for ((code, axes) in axisMap) {
            val v = raw[code] ?: continue
            val range = ranges[code] ?: continue
            for (axis in axes) c.setAxisValue(axis, normalize(axis, v, range))
        }

        // 右スティック：デッドゾーン（ドリフト防止）
        var x = c.getAxisValue(rightX)
        var y = c.getAxisValue(rightY)
        var len = hypot(x, y)
        val dz = deadzone.coerceIn(0f, 0.9f)
        if (len <= dz) {
            x = 0f; y = 0f; len = 0f
        } else {
            // デッドゾーンの外側を 0〜1 に引き伸ばす（少し倒しても、最後まで倒しても、倒した量どおりに）
            val k = ((len - dz) / (1f - dz)).coerceAtMost(1f) / len
            x *= k; y *= k; len = hypot(x, y)
        }

        if (mode == 2) {
            // 超高速：右スティックはマウスの動きとして送るので、スティックとしては送らない
            mouseX = x
            mouseY = y
            x = 0f; y = 0f
        } else if (len > 0f) {
            mouseX = 0f
            mouseY = 0f
            val out = when (mode) {
                1 -> len.pow(0.5f) * mult   // PC版：少し倒しただけで一気に速くなる
                else -> len * mult          // 普通：倒した量 × 倍率
            }.coerceAtMost(1f)
            val k = out / len
            x *= k; y *= k
        } else {
            mouseX = 0f
            mouseY = 0f
        }
        c.setAxisValue(rightX, x.coerceIn(-1f, 1f))
        c.setAxisValue(rightY, y.coerceIn(-1f, 1f))

        val now = SystemClock.uptimeMillis()
        val ev = MotionEvent.obtain(
            now, now, MotionEvent.ACTION_MOVE, 1, props, arrayOf(c),
            0, 0, 1f, 1f, deviceId, 0, InputDevice.SOURCE_JOYSTICK, 0
        )
        try {
            send(ev)
        } catch (t: Throwable) {
        } finally {
            ev.recycle()
        }
    }

    // ───── 超高速：マウスの動き ─────

    private val mouseProps = arrayOf(MotionEvent.PointerProperties().apply {
        id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE
    })

    /** 右スティックを倒している間、8ms ごとにマウスの動きを送り続ける */
    private fun mouseLoop() {
        var last = SystemClock.uptimeMillis()
        var restX = 0f
        var restY = 0f
        while (running) {
            SystemClock.sleep(8)
            val now = SystemClock.uptimeMillis()
            val dt = (now - last) / 1000f
            last = now
            if (mode != 2) { restX = 0f; restY = 0f; continue }
            val x = mouseX
            val y = mouseY
            if (x == 0f && y == 0f) { restX = 0f; restY = 0f; continue }
            // 倒した量どおりの速さ。1 倍で、全開のとき 1 秒に 600 ピクセル分（50 倍なら 30000）
            val speed = 600f * mult
            restX += x * speed * dt
            restY += y * speed * dt
            val dx = restX.toInt().toFloat()
            val dy = restY.toInt().toFloat()
            restX -= dx
            restY -= dy
            if (dx == 0f && dy == 0f) continue
            val c = MotionEvent.PointerCoords().apply {
                this.x = dx
                this.y = dy
                setAxisValue(MotionEvent.AXIS_RELATIVE_X, dx)
                setAxisValue(MotionEvent.AXIS_RELATIVE_Y, dy)
            }
            val ev = MotionEvent.obtain(
                now, now, MotionEvent.ACTION_MOVE, 1, mouseProps, arrayOf(c),
                0, 0, 1f, 1f, -1, 0, InputDevice.SOURCE_MOUSE_RELATIVE, 0
            )
            try {
                send(ev)
            } catch (t: Throwable) {
                error = "マウスの動きを送れません: ${desc(t)}"
            } finally {
                ev.recycle()
            }
        }
    }

    /** 生の値を Android と同じ範囲（スティック -1〜1、トリガー 0〜1）に直す */
    private fun normalize(axis: Int, v: Int, range: IntArray): Float {
        val min = range[0].toFloat()
        val max = range[1].toFloat()
        if (max <= min) return 0f
        return when (axis) {
            MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y -> v.toFloat().sign
            MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER,
            MotionEvent.AXIS_GAS, MotionEvent.AXIS_BRAKE ->
                ((v - min) / (max - min)).coerceIn(0f, 1f)
            else -> {
                val center = range[3].toFloat()
                val side = if (v >= center) (max - center) else (center - min)
                if (side <= 0f) return 0f
                val n = ((v - center) / side).coerceIn(-1f, 1f)
                // 右スティックは上でデッドゾーンをかけるので、ここでは左スティック用の小さいデッドゾーンだけ
                val flat = if (range[2] > 0) range[2] / ((max - min) / 2f) else 0.05f
                if (abs(n) < flat.coerceAtLeast(0.05f)) 0f else n
            }
        }
    }

    private fun desc(t: Throwable): String {
        val c = if (t is java.lang.reflect.InvocationTargetException) (t.cause ?: t) else t
        return "${c.javaClass.simpleName}: ${c.message}"
    }
}
