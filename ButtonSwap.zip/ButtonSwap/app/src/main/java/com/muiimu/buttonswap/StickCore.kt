package com.muiimu.buttonswap

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sign

/**
 * 振り向き感度の本体。ShellService の中（Shizuku の権限のプロセス）で動く。
 * コントローラーの生データを読み、右スティックの値を変えて、ゲームに送り直す。
 * ※ このクラスはアプリとは別のプロセスで動くので、画面や設定ファイルには触らない。
 */
class StickCore(
    private val node: String,
    private val deviceId: Int,
    axisPairs: IntArray,
    rangeData: IntArray,
    private val rightX: Int,
    private val rightY: Int,
    keyPairs: IntArray,
    @Volatile var mode: Int,
    @Volatile var mult: Float,
) {
    private val axisMap = HashMap<Int, MutableList<Int>>()     // ABS コード → Android の軸
    private val ranges = HashMap<Int, IntArray>()              // ABS コード → min, max, flat
    private val keyMap = HashMap<Int, Int>()                   // 生のボタン番号 → Android のボタン
    private val raw = HashMap<Int, Int>()
    private val keyDown = ConcurrentHashMap<Int, Long>()

    @Volatile var running = false
        private set
    @Volatile var error = ""
        private set

    private var input: FileInputStream? = null
    private lateinit var im: Any
    private lateinit var inject: Method

    init {
        var i = 0
        while (i + 1 < axisPairs.size) { axisMap.getOrPut(axisPairs[i]) { mutableListOf() }.add(axisPairs[i + 1]); i += 2 }
        i = 0
        while (i + 3 < rangeData.size) { ranges[rangeData[i]] = intArrayOf(rangeData[i + 1], rangeData[i + 2], rangeData[i + 3]); i += 4 }
        i = 0
        while (i + 1 < keyPairs.size) { keyMap[keyPairs[i]] = keyPairs[i + 1]; i += 2 }
    }

    /** 始める。失敗したら理由を返す */
    fun start(): String {
        try {
            val binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            im = Class.forName("android.hardware.input.IInputManager\$Stub")
                .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
            inject = im.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (t: Throwable) {
            return "InputManager を使えません: ${desc(t)}"
        }

        try {
            input = FileInputStream(File(node))
        } catch (t: Throwable) {
            return "生データを開けません: ${desc(t)}"
        }

        try {
            callIm("disableInputDevice", deviceId)
        } catch (t: Throwable) {
            try { input?.close() } catch (e: Throwable) {}
            return "コントローラーを切り離せません: ${desc(t)}"
        }

        running = true
        error = ""
        Thread({ readLoop() }, "stick-core").start()
        return ""
    }

    fun stop() {
        if (!running) return
        running = false
        for ((key, down) in keyDown) {
            try { send(keyEvent(down, KeyEvent.ACTION_UP, key, 0)) } catch (t: Throwable) {}
        }
        keyDown.clear()
        try { input?.close() } catch (t: Throwable) {}
        restore()
    }

    private fun restore() {
        try { callIm("enableInputDevice", deviceId) } catch (t: Throwable) {}
    }

    private fun callIm(name: String, vararg args: Any): Any? {
        val m = im.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size }
            ?: throw NoSuchMethodException(name)
        return m.invoke(im, *args)
    }

    private fun send(ev: InputEvent) {
        inject.invoke(im, ev, 0)
    }

    // ───── 生データを読んで送り直す ─────

    private fun readLoop() {
        val size = if (android.os.Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) 24 else 16
        val buf = ByteArray(size)
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        var dirty = false
        try {
            val ins = DataInputStream(input!!)
            while (running) {
                ins.readFully(buf)
                val type = bb.getShort(size - 8).toInt() and 0xffff
                val code = bb.getShort(size - 6).toInt() and 0xffff
                val value = bb.getInt(size - 4)
                when (type) {
                    3 -> { raw[code] = value; dirty = true }       // EV_ABS
                    1 -> handleKey(code, value)                     // EV_KEY
                    0 -> if (code == 0 && dirty) { emitMotion(); dirty = false } // EV_SYN
                }
            }
        } catch (t: Throwable) {
            if (running) error = "読み取りが止まりました: ${desc(t)}"
        }
        if (running) {
            // コントローラーが切れたなど
            running = false
            restore()
        }
    }

    private fun handleKey(scan: Int, value: Int) {
        if (value == 2) return
        val key = keyMap[scan] ?: return
        val now = SystemClock.uptimeMillis()
        if (value == 1) {
            keyDown[key] = now
            send(keyEvent(now, KeyEvent.ACTION_DOWN, key, scan))
        } else {
            val down = keyDown.remove(key) ?: now
            send(keyEvent(down, KeyEvent.ACTION_UP, key, scan))
        }
    }

    private fun keyEvent(down: Long, action: Int, key: Int, scan: Int): KeyEvent {
        var src = InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_KEYBOARD
        if (key in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT) src = src or InputDevice.SOURCE_DPAD
        // scanCode は本物と同じにしておく（ボタン入れ替え・連打の設定がそのまま効くように）
        return KeyEvent(down, SystemClock.uptimeMillis(), action, key, 0, 0, deviceId, scan, 0, src)
    }

    private val props = arrayOf(MotionEvent.PointerProperties().apply {
        id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN
    })

    private fun emitMotion() {
        val c = MotionEvent.PointerCoords()
        for ((code, axes) in axisMap) {
            val v = raw[code] ?: continue
            val range = ranges[code] ?: continue
            for (axis in axes) c.setAxisValue(axis, normalize(axis, v, range))
        }

        // 右スティックに感度をかける
        val x = c.getAxisValue(rightX)
        val y = c.getAxisValue(rightY)
        val len = hypot(x, y)
        if (len > 0f) {
            val out = when (mode) {
                1 -> len.pow(0.5f) * mult   // PC版：少し倒しただけで一気に速くなる
                else -> len * mult          // 普通：倍率をかけるだけ
            }.coerceAtMost(1f)
            val k = out / len
            c.setAxisValue(rightX, (x * k).coerceIn(-1f, 1f))
            c.setAxisValue(rightY, (y * k).coerceIn(-1f, 1f))
        }

        val now = SystemClock.uptimeMillis()
        val ev = MotionEvent.obtain(
            now, now, MotionEvent.ACTION_MOVE, 1, props, arrayOf(c),
            0, 0, 1f, 1f, deviceId, 0, InputDevice.SOURCE_JOYSTICK, 0
        )
        try {
            send(ev)
        } finally {
            ev.recycle()
        }
    }

    private fun normalize(axis: Int, v: Int, range: IntArray): Float {
        val min = range[0].toFloat()
        val max = range[1].toFloat()
        if (max <= min) return 0f
        return when (axis) {
            MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y -> v.toFloat().sign
            MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER,
            MotionEvent.AXIS_GAS, MotionEvent.AXIS_BRAKE ->
                ((v - min) / (max - min)).coerceIn(0f, 1f)
            else -> {
                val center = (min + max) / 2f
                val half = (max - min) / 2f
                val n = ((v - center) / half).coerceIn(-1f, 1f)
                val flat = if (range[2] > 0) range[2] / half else 0.05f
                if (abs(n) < flat) 0f else n
            }
        }
    }

    private fun desc(t: Throwable): String {
        val c = if (t is java.lang.reflect.InvocationTargetException) (t.cause ?: t) else t
        return "${c.javaClass.simpleName}: ${c.message}"
    }
}
