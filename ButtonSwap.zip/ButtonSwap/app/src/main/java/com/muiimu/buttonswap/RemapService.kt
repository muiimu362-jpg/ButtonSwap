package com.muiimu.buttonswap

import android.accessibilityservice.AccessibilityService
import android.hardware.input.InputManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * ユーザー補助サービス。ゲームより先にボタン入力を受け取り、
 * 保存された設定（「完了」で固定したもの）に従って入れ替え・連打をして送り直す。
 */
class RemapService : AccessibilityService() {

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler

    /** 連打中のボタン（元のキーコード → 状態） */
    private val turbos = HashMap<Int, TurboJob>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        thread = HandlerThread("turbo").also { it.start() }
        handler = Handler(thread.looper)
        getSystemService(InputManager::class.java)?.registerInputDeviceListener(deviceListener, handler)
        Diag.connected(true)
        StickEngine.apply(this)
    }

    /** 全部の連打を止める（押しっぱなしになっているものは離す） */
    private fun stopAllTurbo() {
        handler.post {
            for (job in turbos.values.toList()) job.stop()
            turbos.clear()
        }
    }

    override fun onDestroy() {
        StickEngine.stop()
        getSystemService(InputManager::class.java)?.unregisterInputDeviceListener(deviceListener)
        if (::handler.isInitialized) stopAllTurbo()
        Diag.connected(false)
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!fromController(event)) return false

        // 自分で送った入力はそのまま通す（A⇄B 入れ替えや連打で無限ループしないように）
        if (Injector.isInjected(event)) return false

        // 生のボタン番号と Android のボタンの対応を覚える（振り向き感度の実験で使う）
        if (!StickEngine.isRunning() && event.scanCode > 0) {
            ScanMap.learn(this, event.scanCode, event.keyCode)
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            Diag.received("${Mapping.nameOf(event.keyCode)}（${KeyEvent.keyCodeToString(event.keyCode)}）")
        }

        val profile = Mapping.active(this)
        val cfg = profile.buttons[event.keyCode] ?: return false

        if (!Injector.ready()) {
            Diag.result("❌ Shizuku が使えないので変更できません（Shizuku を起動して許可してください）")
            return false // 元のまま届ける
        }
        val target = cfg.target ?: event.keyCode

        if (cfg.turbo) {
            handleTurbo(event, target, profile)
            return true
        }
        if (target == event.keyCode) return false

        Injector.inject(event, target)
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            Diag.result("✅ ${Mapping.nameOf(event.keyCode)} → ${Mapping.nameOf(target)} に変えて送りました")
        }
        return true // 元の入力はゲームに届けない
    }

    // ───── 連打 ─────
    //
    // ・ポンと押す（TAP_MS より短い）→ 設定した回数だけ殴る
    // ・長押し → 普通の長押しを 1 回だけ（離すまで押しっぱなし。ブロック壊しなど用）
    //
    // 押した瞬間はまず普通に「押す」を送り、離したときの長さでどちらか決める。
    // 連打まわりの処理はすべて handler のスレッドで行う。

    private inner class TurboJob(
        val srcCode: Int,
        val target: Int,
        val intervalMs: Int,
        val deviceId: Int,
        val source: Int,
    ) {
        var cancelled = false
        var pressing = false
        var pressDown = 0L
        var extraLeft = 0
        /** 本物のボタンをまだ押しているか */
        var held = false
        var repeat = 0

        /** 追加で殴るときに押している時間（間隔の半分。短すぎるとゲームが拾わないので最低 15ms） */
        private val pressMs = (intervalMs / 2).coerceAtLeast(15).toLong()

        fun pressNow() {
            pressDown = SystemClock.uptimeMillis()
            Injector.injectFresh(target, KeyEvent.ACTION_DOWN, pressDown, deviceId, source)
            pressing = true
        }

        fun releaseNow() {
            if (!pressing) return
            Injector.injectFresh(target, KeyEvent.ACTION_UP, pressDown, deviceId, source)
            pressing = false
        }

        /** 追加の 1 回を押す */
        val fireExtra: Runnable = Runnable {
            if (cancelled || extraLeft <= 0) { finish(); return@Runnable }
            pressNow()
            handler.postDelayed(releaseExtra, pressMs)
        }

        /** 追加の 1 回を離す → 残りがあれば次を予約 */
        val releaseExtra: Runnable = Runnable {
            releaseNow()
            extraLeft--
            if (!cancelled && extraLeft > 0) {
                handler.postDelayed(fireExtra, (intervalMs - pressMs).coerceAtLeast(10))
            } else {
                finish()
            }
        }

        /** 長押し中：「まだ押してる」の合図（リピート）を送り続ける */
        val repeatTick: Runnable = Runnable {
            if (cancelled || !held || !pressing) return@Runnable
            repeat++
            val flags = if (repeat == 1) KeyEvent.FLAG_LONG_PRESS else 0
            Injector.injectFresh(target, KeyEvent.ACTION_DOWN, pressDown, deviceId, source, repeat, flags)
            handler.postDelayed(repeatTick, REPEAT_MS)
        }

        fun stop() {
            cancelled = true
            held = false
            handler.removeCallbacks(fireExtra)
            handler.removeCallbacks(releaseExtra)
            handler.removeCallbacks(repeatTick)
            releaseNow()
        }

        fun finish() {
            if (turbos[srcCode] === this) turbos.remove(srcCode)
        }
    }

    private fun handleTurbo(e: KeyEvent, target: Int, p: Profile) {
        val code = e.keyCode
        when (e.action) {
            KeyEvent.ACTION_DOWN -> {
                if (e.repeatCount > 0) return // 長押し中の自動リピートは無視
                val deviceId = e.deviceId
                val source = e.source
                handler.post {
                    turbos.remove(code)?.stop() // 前の連打が残っていたら止める
                    val job = TurboJob(code, target, p.intervalMs, deviceId, source)
                    turbos[code] = job
                    job.held = true
                    job.pressNow() // まずは普通に押す
                    // 0.2 秒押し続けたら長押し：リピートを送り始める
                    handler.postDelayed(job.repeatTick, TAP_MS)
                }
            }
            KeyEvent.ACTION_UP -> {
                val burst = p.burst
                handler.post {
                    val job = turbos[code] ?: return@post
                    if (job.cancelled) return@post
                    val heldMs = SystemClock.uptimeMillis() - job.pressDown
                    job.held = false
                    handler.removeCallbacks(job.repeatTick)
                    job.releaseNow()
                    if (heldMs < TAP_MS && burst > 1) {
                        // ポン押し → 残りの回数を追加で殴る
                        job.extraLeft = burst - 1
                        val wait = (job.pressDown + job.intervalMs - SystemClock.uptimeMillis())
                            .coerceAtLeast(10)
                        handler.postDelayed(job.fireExtra, wait)
                        Diag.result("✅ ${Mapping.nameOf(code)}：ポン押し → ${burst} 回殴りました")
                    } else {
                        // 長押し → 1 回だけで終わり
                        job.finish()
                        Diag.result("✅ ${Mapping.nameOf(code)}：長押し → 1 回の長押しとして送りました")
                    }
                }
            }
        }
    }

    /**
     * 本物のコントローラーからの入力だけ true。
     * 画面タッチ・スマホ本体のボタン・ソフトキーボードなどには反応しない。
     */
    private fun fromController(e: KeyEvent): Boolean {
        if (e.deviceId == KeyCharacterMap.VIRTUAL_KEYBOARD) return false
        val dev = e.device ?: return false
        if (dev.isVirtual) return false
        val gamepad = (dev.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (dev.sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!gamepad) return false
        val src = e.source
        val fromPad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
            (src and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
        return fromPad && e.keyCode in Mapping.CODES
    }

    // ───── コントローラーが切れたら連打を全部止める ─────

    private val deviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            StickEngine.apply(this@RemapService)
        }
        override fun onInputDeviceChanged(deviceId: Int) {}
        override fun onInputDeviceRemoved(deviceId: Int) {
            if (::handler.isInitialized) stopAllTurbo()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {
        if (::handler.isInitialized) stopAllTurbo()
    }

    companion object {
        /** これより短く押したら「ポン押し」、長ければ「長押し」 */
        private const val TAP_MS = 200L
        /** 長押し中に「まだ押してる」を送る間隔 */
        private const val REPEAT_MS = 50L
    }
}
