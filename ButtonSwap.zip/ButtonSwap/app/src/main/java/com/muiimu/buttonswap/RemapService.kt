package com.muiimu.buttonswap

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * ユーザー補助サービス。ゲームより先にボタン入力を受け取り、
 * 設定に応じて「別のボタンに変える」「連射にする」をしてから送り直す。
 */
class RemapService : AccessibilityService() {

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler

    /** 連射中のボタン（元のキーコード → 状態） */
    private val turbos = HashMap<Int, TurboJob>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        thread = HandlerThread("turbo").also { it.start() }
        handler = Handler(thread.looper)
    }

    override fun onDestroy() {
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!fromController(event)) return false

        // 自分で送り直した入力はそのまま通す（A⇄B 入れ替えで無限ループしないように）
        if (Injector.consumeIfInjected(event)) return false

        val cfg = Mapping.config(this, event.keyCode) ?: return false
        if (!Injector.ready()) return false // Shizuku が使えないときは元のまま
        val target = cfg.target ?: event.keyCode

        if (cfg.turbo) {
            handleTurbo(event, target, cfg)
            return true
        }

        if (target == event.keyCode) return false
        Injector.inject(event, target)
        return true // 元の入力はゲームに届けない
    }

    // ───── 連射 ─────

    private inner class TurboJob(
        val srcCode: Int,
        val target: Int,
        val cfg: ButtonConfig,
        val deviceId: Int,
        val source: Int,
    ) {
        @Volatile var held = true
        @Volatile var cancelled = false
        var count = 0
        var pressDown = 0L

        /** 1 回分「押す」 */
        val fire: Runnable = Runnable {
            if (cancelled) return@Runnable
            pressDown = SystemClock.uptimeMillis()
            Injector.injectFresh(target, KeyEvent.ACTION_DOWN, pressDown, deviceId, source)
            handler.postDelayed(release, pressMs())
        }

        /** 1 回分「離す」→ まだ続けるなら次を予約 */
        val release: Runnable = Runnable {
            Injector.injectFresh(target, KeyEvent.ACTION_UP, pressDown, deviceId, source)
            count++
            if (!cancelled && (held || count < cfg.burst)) {
                handler.postDelayed(fire, (cfg.intervalMs - pressMs()).coerceAtLeast(10).toLong())
            } else {
                synchronized(turbos) { if (turbos[srcCode] === this) turbos.remove(srcCode) }
            }
        }

        /** 押している時間（間隔の半分。短すぎるとゲームが拾わないので最低 15ms） */
        fun pressMs(): Long = (cfg.intervalMs / 2).coerceAtLeast(15).toLong()
    }

    private fun handleTurbo(e: KeyEvent, target: Int, cfg: ButtonConfig) {
        when (e.action) {
            KeyEvent.ACTION_DOWN -> {
                if (e.repeatCount > 0) return // 長押しの自動リピートは無視（連射はこちらで作る）
                val job = TurboJob(e.keyCode, target, cfg, e.deviceId, e.source)
                synchronized(turbos) {
                    turbos[e.keyCode]?.let { old ->
                        // 前の連射は止める（押している途中なら離す処理だけは実行される）
                        old.held = false
                        old.cancelled = true
                        handler.removeCallbacks(old.fire)
                    }
                    turbos[e.keyCode] = job
                }
                handler.post(job.fire)
            }
            KeyEvent.ACTION_UP -> {
                synchronized(turbos) { turbos[e.keyCode]?.held = false }
                // 最低回数（1 回押しの回数）に届くまでは release 側が続けてくれる
            }
        }
    }

    private fun fromController(e: KeyEvent): Boolean {
        val s = e.source
        return KeyEvent.isGamepadButton(e.keyCode) ||
            (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
