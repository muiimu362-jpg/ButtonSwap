package com.muiimu.buttonswap

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * ユーザー補助サービス。ゲームより先にボタン入力を受け取り、
 * 保存された設定（「完了」で固定したもの）に従って入れ替え・連打をして送り直す。
 */
class RemapService : AccessibilityService() {

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler

    /** 連打中のボタン（元のキーコード → 状態） */
    private val turbos = HashMap<Int, TurboJob>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        thread = HandlerThread("turbo").also { it.start() }
        handler = Handler(thread.looper)
        Diag.connected(true)
    }

    override fun onDestroy() {
        Diag.connected(false)
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!fromController(event)) return false

        // 自分で送り直した入力はそのまま通す（A⇄B 入れ替えで無限ループしないように）
        if (Injector.consumeIfInjected(event)) return false

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            Diag.received("${Mapping.nameOf(event.keyCode)}（${KeyEvent.keyCodeToString(event.keyCode)}）")
        }

        val profile = Mapping.active(this)
        val cfg = profile.buttons[event.keyCode] ?: return false

        if (!Injector.ready()) {
            Diag.result("❌ Shizuku が使えないので変更できません（Shizuku を起動して許可してください）")
            return false // 元のまま届ける
        }
        val target = cfg.target ?: event.keyCode

        if (cfg.turbo) {
            handleTurbo(event, target, profile)
            return true
        }
        if (target == event.keyCode) return false

        Injector.inject(event, target)
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            Diag.result("✅ ${Mapping.nameOf(event.keyCode)} → ${Mapping.nameOf(target)} に変えて送りました")
        }
        return true // 元の入力はゲームに届けない
    }

    // ───── 連打 ─────

    private inner class TurboJob(
        val srcCode: Int,
        val target: Int,
        val intervalMs: Int,
        val burst: Int,
        val deviceId: Int,
        val source: Int,
    ) {
        @Volatile var held = true
        @Volatile var cancelled = false
        var count = 0
        var pressDown = 0L

        /** 押している時間（間隔の半分。短すぎるとゲームが拾わないので最低 15ms） */
        private val pressMs = (intervalMs / 2).coerceAtLeast(15).toLong()

        /** 1 回分「押す」 */
        val fire: Runnable = Runnable {
            if (cancelled) return@Runnable
            pressDown = SystemClock.uptimeMillis()
            Injector.injectFresh(target, KeyEvent.ACTION_DOWN, pressDown, deviceId, source)
            handler.postDelayed(release, pressMs)
        }

        /** 1 回分「離す」→ まだ続けるなら次を予約 */
        val release: Runnable = Runnable {
            Injector.injectFresh(target, KeyEvent.ACTION_UP, pressDown, deviceId, source)
            count++
            if (!cancelled && (held || count < burst)) {
                handler.postDelayed(fire, (intervalMs - pressMs).coerceAtLeast(10))
            } else {
                synchronized(turbos) { if (turbos[srcCode] === this) turbos.remove(srcCode) }
            }
        }
    }

    private fun handleTurbo(e: KeyEvent, target: Int, p: Profile) {
        when (e.action) {
            KeyEvent.ACTION_DOWN -> {
                if (e.repeatCount > 0) return // 長押しの自動リピートは無視（連打はこちらで作る）
                val job = TurboJob(e.keyCode, target, p.intervalMs, p.burst, e.deviceId, e.source)
                synchronized(turbos) {
                    turbos[e.keyCode]?.let { old ->
                        old.held = false
                        old.cancelled = true
                        handler.removeCallbacks(old.fire)
                    }
                    turbos[e.keyCode] = job
                }
                handler.post(job.fire)
                Diag.result("✅ ${Mapping.nameOf(e.keyCode)} を連打（${p.burst} 回）で送りました")
            }
            KeyEvent.ACTION_UP -> {
                synchronized(turbos) { turbos[e.keyCode]?.held = false }
            }
        }
    }

    private fun fromController(e: KeyEvent): Boolean {
        val s = e.source
        return KeyEvent.isGamepadButton(e.keyCode) ||
            (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
