package com.muiimu.buttonswap

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Shizuku の権限（ADB と同じ）で動くサービス（ShellService）を呼び出す。
 * Shizuku が正式に用意している「UserService」という仕組みを使う。
 */
object Shell {

    @Volatile private var pkg: String? = null
    @Volatile private var service: IShellService? = null
    @Volatile private var latch = CountDownLatch(1)
    @Volatile private var binding = false

    /** 最後に失敗した理由（画面に出す用） */
    @Volatile var lastError: String = ""

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                service = IShellService.Stub.asInterface(binder)
            }
            binding = false
            latch.countDown()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            binding = false
        }
    }

    fun init(ctx: Context) {
        pkg = ctx.applicationContext.packageName
    }

    /** サービスにつなぐ（最大 8 秒待つ）。画面のスレッドからは呼ばないこと */
    private fun get(): IShellService? {
        service?.let { if (it.asBinder().pingBinder()) return it }
        service = null
        if (Looper.myLooper() == Looper.getMainLooper()) {
            lastError = "画面のスレッドからは呼べません"
            return null
        }
        if (!Injector.ready()) {
            lastError = "Shizuku が使えません"
            return null
        }
        val p = pkg ?: run { lastError = "準備ができていません"; return null }
        try {
            synchronized(this) {
                if (!binding) {
                    latch = CountDownLatch(1)
                    binding = true
                    val args = Shizuku.UserServiceArgs(ComponentName(p, ShellService::class.java.name))
                        .daemon(false)
                        .processNameSuffix("shell")
                        .debuggable(false)
                        .version(1)
                    // bindUserService は画面のスレッドで呼ぶ必要がある
                    android.os.Handler(Looper.getMainLooper()).post {
                        try {
                            Shizuku.bindUserService(args, conn)
                        } catch (t: Throwable) {
                            lastError = "bindUserService: ${t.javaClass.simpleName}: ${t.message}"
                            binding = false
                            latch.countDown()
                        }
                    }
                }
            }
            if (!latch.await(8, TimeUnit.SECONDS)) {
                binding = false
                lastError = "Shizuku のサービスが起動しません（8 秒待ちました）"
                return null
            }
        } catch (t: Throwable) {
            lastError = "${t.javaClass.simpleName}: ${t.message}"
            return null
        }
        return service ?: run {
            if (lastError.isEmpty()) lastError = "Shizuku のサービスにつながりません"
            null
        }
    }

    /** コマンドを動かして、出力をまとめて返す（失敗したら null） */
    fun run(cmd: String, timeoutSec: Long): String? {
        val s = get() ?: return null
        return try {
            s.run(cmd, timeoutSec.toInt())
        } catch (t: Throwable) {
            lastError = "run: ${t.javaClass.simpleName}: ${t.message}"
            null
        }
    }

    /** ファイルを読み取り用に開く（失敗したら例外） */
    fun open(path: String): ParcelFileDescriptor {
        val s = get() ?: throw IllegalStateException(lastError)
        return s.open(path)
    }

    /** getevent -p の出力から、名前が一致する /dev/input/eventX を探す */
    fun findNode(list: String, name: String): String? {
        val blocks = deviceBlocks(list)
        blocks.firstOrNull { it.second.equals(name, true) }?.let { return it.first }
        blocks.firstOrNull { it.second.contains(name, true) || name.contains(it.second, true) }
            ?.let { return it.first }
        return null
    }

    /** getevent -p の出力から、そのデバイスの軸の範囲（ABS コード → min, max, flat）を取り出す */
    fun absRanges(list: String, node: String): Map<Int, IntArray> {
        val block = list.split("add device").firstOrNull { it.contains(node) } ?: return emptyMap()
        val re = Regex("([0-9a-f]{4})\\s*:\\s*value\\s*(-?\\d+),\\s*min\\s*(-?\\d+),\\s*max\\s*(-?\\d+),\\s*fuzz\\s*(-?\\d+),\\s*flat\\s*(-?\\d+)")
        val m = HashMap<Int, IntArray>()
        for (r in re.findAll(block)) {
            val g = r.groupValues
            m[g[1].toInt(16)] = intArrayOf(g[3].toInt(), g[4].toInt(), g[6].toInt())
        }
        return m
    }

    /** (node, name) の一覧 */
    private fun deviceBlocks(list: String): List<Pair<String, String>> {
        val res = mutableListOf<Pair<String, String>>()
        var node: String? = null
        for (line in list.lines()) {
            Regex("add device \\d+: (\\S+)").find(line)?.let { node = it.groupValues[1] }
            val n = Regex("name:\\s+\"(.*)\"").find(line)?.groupValues?.get(1)
            val cur = node
            if (n != null && cur != null) res += cur to n
        }
        return res
    }
}
