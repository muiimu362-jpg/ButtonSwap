package com.muiimu.buttonswap

import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit

/** Shizuku（ADB と同じ権限）でコマンドを動かす */
object Shell {

    /** コマンドを起動して、そのプロセスを返す（出力は自分で読む） */
    fun newProcess(cmd: String): Process {
        // Shizuku API 13 では newProcess が非公開になったので、リフレクションで呼ぶ
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    /** コマンドを動かして、出力をまとめて返す（失敗したら null） */
    fun run(cmd: String, timeoutSec: Long): String? = try {
        val p = newProcess(cmd)
        val out = StringBuilder()
        val reader = Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { synchronized(out) { out.appendLine(it) } }
            } catch (e: Throwable) {
            }
        }.apply { start() }
        p.waitFor(timeoutSec, TimeUnit.SECONDS)
        p.destroy()
        reader.join(500)
        synchronized(out) { out.toString() }
    } catch (t: Throwable) {
        null
    }

    /** getevent -p の出力から、名前が一致する /dev/input/eventX を探す */
    fun findNode(list: String, name: String): String? {
        val blocks = deviceBlocks(list)
        blocks.firstOrNull { it.second.equals(name, true) }?.let { return it.first }
        blocks.firstOrNull { it.second.contains(name, true) || name.contains(it.second, true) }
            ?.let { return it.first }
        return null
    }

    /** getevent -p の出力から、そのデバイスの軸の範囲（ABS コード → min, max, flat）を取り出す */
    fun absRanges(list: String, node: String): Map<Int, IntArray> {
        val block = list.split("add device").firstOrNull { it.contains(node) } ?: return emptyMap()
        val re = Regex("([0-9a-f]{4})\\s*:\\s*value\\s*(-?\\d+),\\s*min\\s*(-?\\d+),\\s*max\\s*(-?\\d+),\\s*fuzz\\s*(-?\\d+),\\s*flat\\s*(-?\\d+)")
        val m = HashMap<Int, IntArray>()
        for (r in re.findAll(block)) {
            val g = r.groupValues
            m[g[1].toInt(16)] = intArrayOf(g[3].toInt(), g[4].toInt(), g[6].toInt())
        }
        return m
    }

    /** (node, name) の一覧 */
    private fun deviceBlocks(list: String): List<Pair<String, String>> {
        val res = mutableListOf<Pair<String, String>>()
        var node: String? = null
        for (line in list.lines()) {
            Regex("add device \\d+: (\\S+)").find(line)?.let { node = it.groupValues[1] }
            val n = Regex("name:\\s+\"(.*)\"").find(line)?.groupValues?.get(1)
            val cur = node
            if (n != null && cur != null) res += cur to n
        }
        return res
    }
}
