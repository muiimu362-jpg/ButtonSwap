package com.muiimu.buttonswap

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var lastKeyText: TextView
    private lateinit var summaryText: TextView
    private lateinit var controller: ControllerView
    private lateinit var styleText: TextView
    private lateinit var byLabelButton: Button

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refreshStatus() } }
    private val binderListener =
        Shizuku.OnBinderReceivedListener { runOnUiThread { refreshStatus() } }
    private val binderDeadListener =
        Shizuku.OnBinderDeadListener { runOnUiThread { refreshStatus() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Pad.load(this)
        setContentView(buildUi())
        refreshStyle()
        refreshConfigs()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshStyle()
    }

    /** 実機のボタンを押すと、絵の中の同じボタンが光る */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val isPad = KeyEvent.isGamepadButton(code) ||
            code in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        if (isPad && event.action == KeyEvent.ACTION_DOWN) {
            // 種類をまだ選んでいなければ、押されたコントローラーのメーカーで自動判定
            if (!Pad.hasSavedStyle(this)) {
                event.device?.let { Pad.styleOfVendor(it.vendorId) }?.let {
                    if (it != Pad.style) { Pad.style = it; refreshStyle() }
                }
            }
            controller.flash(code)
            lastKeyText.text = "今届いたボタン: ${Mapping.nameOf(code)}（${KeyEvent.keyCodeToString(code)}）"
        }
        if (KeyEvent.isGamepadButton(code)) return true
        return super.dispatchKeyEvent(event)
    }

    private fun buildUi(): View {
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(title(getString(R.string.app_name), 24f))

        statusText = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        root.addView(statusText)
        root.addView(button("① ユーザー補助の設定を開く") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("② Shizuku の権限をリクエスト") { requestShizuku() })

        root.addView(title("コントローラーの種類", 18f).apply { setPadding(0, dp(16), 0, dp(4)) })
        styleText = TextView(this).apply { textSize = 14f }
        root.addView(styleText)
        val styleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (st in PadStyle.entries) {
            styleRow.addView(button(st.title) {
                Pad.style = st
                Pad.save(this)
                refreshStyle()
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(styleRow)
        byLabelButton = button("") {
            Pad.nintendoByLabel = !Pad.nintendoByLabel
            Pad.save(this)
            refreshStyle()
        }
        root.addView(byLabelButton)

        root.addView(title("ボタンをタップして設定", 18f).apply { setPadding(0, dp(16), 0, dp(4)) })
        root.addView(TextView(this).apply {
            text = "オレンジ＝入れ替え中 / 黄色い枠＋⚡＝連射 / 水色＝今押したボタン"
            textSize = 13f
        })

        controller = ControllerView(this).apply { onButtonTap = { code -> openEditor(code) } }
        root.addView(controller, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        lastKeyText = TextView(this).apply {
            text = "コントローラーのボタンを押すと、絵の中の同じボタンが光ります"
            textSize = 14f
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(lastKeyText)

        summaryText = TextView(this).apply { textSize = 15f; setPadding(0, dp(4), 0, dp(8)) }
        root.addView(summaryText)

        root.addView(button("下と右のボタンを入れ替える（おまかせ）") {
            Mapping.set(this, KeyEvent.KEYCODE_BUTTON_A,
                (Mapping.config(this, KeyEvent.KEYCODE_BUTTON_A) ?: ButtonConfig())
                    .copy(target = KeyEvent.KEYCODE_BUTTON_B))
            Mapping.set(this, KeyEvent.KEYCODE_BUTTON_B,
                (Mapping.config(this, KeyEvent.KEYCODE_BUTTON_B) ?: ButtonConfig())
                    .copy(target = KeyEvent.KEYCODE_BUTTON_A))
            refreshConfigs()
        })
        root.addView(button("すべてリセット") { Mapping.clear(this); refreshConfigs() })

        root.addView(TextView(this).apply {
            text = "※ スティックやアナログトリガーは変更できません。\n" +
                "※ コントローラーによっては十字キーの変更が効かないことがあります。\n" +
                "※ オンライン対戦で連射を使うと、ゲームの規約違反になることがあります。"
            textSize = 12f
            setPadding(0, dp(12), 0, 0)
        })

        return ScrollView(this).apply { addView(root) }
    }

    /** 1 つのボタンの設定ダイアログ */
    private fun openEditor(code: Int) {
        val cur = Mapping.config(this, code) ?: ButtonConfig()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        // 入れ替え先
        box.addView(TextView(this).apply { text = "押したときにゲームに届くボタン"; textSize = 15f })
        val options = listOf("そのまま（${Mapping.nameOf(code)}）") + Mapping.BUTTONS.map { it.first }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            val idx = Mapping.BUTTONS.indexOfFirst { it.second == cur.target }
            setSelection(if (idx >= 0) idx + 1 else 0)
        }
        box.addView(spinner)

        // 連射
        val turboSwitch = Switch(this).apply {
            text = "連射（押している間、自動で連打）"
            textSize = 15f
            isChecked = cur.turbo
            setPadding(0, dp(16), 0, dp(8))
        }
        box.addView(turboSwitch)

        val turboArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val intervalLabel = TextView(this).apply { textSize = 14f }
        val intervalBar = SeekBar(this).apply {
            max = (Mapping.MAX_INTERVAL - Mapping.MIN_INTERVAL) / 10
            progress = (cur.intervalMs - Mapping.MIN_INTERVAL) / 10
        }
        val burstLabel = TextView(this).apply { textSize = 14f; setPadding(0, dp(12), 0, 0) }
        val burstBar = SeekBar(this).apply {
            max = Mapping.MAX_BURST - 1
            progress = cur.burst - 1
        }

        fun intervalMs() = Mapping.MIN_INTERVAL + intervalBar.progress * 10
        fun updateLabels() {
            val ms = intervalMs()
            intervalLabel.text = String.format(
                Locale.JAPAN, "連打の速さ：%.2f 秒ごと（1 秒に約 %.1f 回）", ms / 1000f, 1000f / ms
            )
            burstLabel.text = "1 回押しただけで出る回数：${burstBar.progress + 1} 回"
        }
        val onChange = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = updateLabels()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        intervalBar.setOnSeekBarChangeListener(onChange)
        burstBar.setOnSeekBarChangeListener(onChange)
        updateLabels()

        turboArea.addView(intervalLabel)
        turboArea.addView(intervalBar)
        turboArea.addView(burstLabel)
        turboArea.addView(burstBar)
        turboArea.addView(TextView(this).apply {
            text = "例：0.10 秒・3 回 → ポンと 1 回押すだけで 3 回攻撃。押しっぱなしなら 1 秒に 10 回。"
            textSize = 12f
            setPadding(0, dp(6), 0, 0)
        })
        turboArea.visibility = if (cur.turbo) View.VISIBLE else View.GONE
        turboSwitch.setOnCheckedChangeListener { _, on ->
            turboArea.visibility = if (on) View.VISIBLE else View.GONE
        }
        box.addView(turboArea)

        AlertDialog.Builder(this)
            .setTitle("「${Mapping.nameOf(code)}」ボタンの設定")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("保存") { _, _ ->
                val pos = spinner.selectedItemPosition
                Mapping.set(this, code, ButtonConfig(
                    target = if (pos == 0) null else Mapping.BUTTONS[pos - 1].second,
                    turbo = turboSwitch.isChecked,
                    intervalMs = intervalMs(),
                    burst = burstBar.progress + 1,
                ))
                refreshConfigs()
            }
            .setNeutralButton("元に戻す") { _, _ ->
                Mapping.set(this, code, ButtonConfig())
                refreshConfigs()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun refreshStyle() {
        val name = Pad.connectedName()
        styleText.text = "今の表示: ${Pad.style.title}" +
            (if (name != null) "\nつながっているコントローラー: $name" else "\nコントローラーがつながっていません") +
            "\n押したボタンと違う場所が光るときは、種類を変えるか下のボタンを押してください"
        byLabelButton.visibility = if (Pad.style == PadStyle.NINTENDO) View.VISIBLE else View.GONE
        byLabelButton.text = if (Pad.nintendoByLabel) "Switch の A/B・X/Y 配置：表記どおり（タップで切替）"
            else "Switch の A/B・X/Y 配置：位置どおり（タップで切替）"
        if (::controller.isInitialized) refreshConfigs()
    }

    private fun refreshConfigs() {
        val all = Mapping.all(this)
        controller.configs = all
        summaryText.text = if (all.isEmpty()) {
            "変更なし"
        } else {
            "今の設定：\n" + Mapping.BUTTONS.mapNotNull { (name, code) ->
                val c = all[code] ?: return@mapNotNull null
                val parts = mutableListOf<String>()
                c.target?.let { parts += "→ ${Mapping.nameOf(it)}" }
                if (c.turbo) parts += String.format(
                    Locale.JAPAN, "⚡連射 %.2f秒・%d回", c.intervalMs / 1000f, c.burst
                )
                "・$name ${parts.joinToString("  ")}"
            }.joinToString("\n")
        }
    }

    private fun requestShizuku() {
        when {
            !Injector.shizukuRunning() ->
                toast("Shizuku が起動していません。Shizuku アプリで「開始」してください")
            Shizuku.isPreV11() -> toast("Shizuku が古いので更新してください")
            Injector.hasPermission() -> toast("すでに許可されています")
            Shizuku.shouldShowRequestPermissionRationale() ->
                toast("Shizuku アプリの中で、このアプリを許可してください")
            else -> Shizuku.requestPermission(1)
        }
    }

    private fun refreshStatus() {
        val a11y = if (accessibilityEnabled()) "✅ ON" else "❌ OFF"
        val shizuku = when {
            !Injector.shizukuRunning() -> "❌ 起動していません"
            !Injector.hasPermission() -> "⚠️ 権限がありません"
            else -> "✅ OK"
        }
        statusText.text = "ユーザー補助: $a11y\nShizuku: $shizuku"
    }

    private fun accessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, RemapService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun title(t: String, size: Float) = TextView(this).apply {
        text = t
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
