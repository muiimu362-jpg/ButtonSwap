package com.muiimu.buttonswap

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private var uiReady = false

    /** 編集中の設定。「完了」を押すまでゲームには反映されない */
    private lateinit var draft: Profile

    private lateinit var warnText: TextView
    private lateinit var statusText: TextView
    private lateinit var styleText: TextView
    private lateinit var byLabelButton: Button
    private lateinit var controller: ControllerView
    private lateinit var lastKeyText: TextView
    private lateinit var summaryText: TextView
    private lateinit var unsavedText: TextView
    private lateinit var diagText: TextView

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refreshStatus() } }
    private val binderListener =
        Shizuku.OnBinderReceivedListener { runOnUiThread { refreshStatus() } }
    private val binderDeadListener =
        Shizuku.OnBinderDeadListener { runOnUiThread { refreshStatus() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shell.init(this)
        Pad.load(this)
        draft = Mapping.active(this)
        setContentView(buildUi())
        uiReady = true
        // 画面ができてから Shizuku の通知を受け取る（先に受け取ると、まだない画面を触って落ちる）
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Diag.onChange = { refreshDiag() }
        refreshAll()
    }

    override fun onDestroy() {
        Diag.onChange = null
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
        StickEngine.apply(this)
    }

    /** 実機のボタンを押すと、絵の中の同じボタンが光る */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val isPad = KeyEvent.isGamepadButton(code) ||
            code in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        if (isPad && event.action == KeyEvent.ACTION_DOWN && uiReady) {
            if (!Pad.hasSavedStyle(this)) {
                event.device?.let { Pad.styleOfVendor(it.vendorId) }?.let {
                    if (it != Pad.style) { Pad.style = it; refreshAll() }
                }
            }
            controller.flash(code)
            lastKeyText.text = "今届いたボタン: ${Mapping.nameOf(code)}"
        }
        if (KeyEvent.isGamepadButton(code)) return true
        return super.dispatchKeyEvent(event)
    }

    // ───────────── 画面 ─────────────

    private fun buildUi(): View {
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(title(getString(R.string.app_name), 24f))

        // 動かない原因（赤字）
        warnText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#FF5252"))
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(warnText)

        statusText = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        root.addView(statusText)
        root.addView(button("① ユーザー補助の設定を開く") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("② Shizuku の権限をリクエスト") { requestShizuku() })

        // コントローラーの種類
        root.addView(title("コントローラーの種類", 18f).apply { setPadding(0, dp(16), 0, dp(4)) })
        styleText = TextView(this).apply { textSize = 14f }
        root.addView(styleText)
        val styleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (st in PadStyle.entries) {
            styleRow.addView(button(st.title) {
                Pad.style = st
                Pad.save(this)
                refreshAll()
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(styleRow)
        byLabelButton = button("") {
            Pad.nintendoByLabel = !Pad.nintendoByLabel
            Pad.save(this)
            refreshAll()
        }
        root.addView(byLabelButton)

        // コントローラーの絵
        root.addView(title("ボタンをタップして配置を変える", 18f).apply { setPadding(0, dp(16), 0, dp(4)) })
        root.addView(TextView(this).apply {
            text = "オレンジ＝入れ替え / 黄色い枠＋⚡＝連打 / 水色＝今押したボタン"
            textSize = 13f
        })
        controller = ControllerView(this).apply { onButtonTap = { code -> openEditor(code) } }
        root.addView(controller, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        lastKeyText = TextView(this).apply {
            text = "コントローラーのボタンを押すと、絵の中の同じボタンが光ります"
            textSize = 14f
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(lastKeyText)

        summaryText = TextView(this).apply { textSize = 15f; setPadding(0, dp(4), 0, dp(8)) }
        root.addView(summaryText)

        unsavedText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#FFAB40"))
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(unsavedText)

        // 完了 / リセット / 設定
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("✅ 完了") { commit() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button("↩ リセット") { revert() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        root.addView(button("⚙ 設定（連打のスピード・回数）") { openSettings() })
        root.addView(button("すべて初期状態に戻す") { confirmClearAll() })

        // 実験：スティック感度
        root.addView(title("🧪 振り向き感度が動かないときの原因調べ", 18f).apply { setPadding(0, dp(20), 0, dp(4)) })
        root.addView(TextView(this).apply {
            text = "振り向き感度（⚙ 設定）がうまく動かないときに押してください。\n" +
                "コントローラーをつないだまま押して、表示が出たら 3 秒間右スティックをぐるぐる回してください。\n" +
                "※ 調べる間、一瞬だけコントローラーが反応しなくなります。"
            textSize = 13f
        })
        val probeText = TextView(this).apply { textSize = 13f; setPadding(0, dp(6), 0, 0) }
        root.addView(button("このスマホでできるか調べる") {
            probeText.text = "調べています…\n"
            Thread {
                Probe.run { line -> runOnUiThread { probeText.append(line + "\n") } }
            }.start()
        })
        root.addView(probeText)

        // 診断
        root.addView(title("動作チェック", 18f).apply { setPadding(0, dp(20), 0, dp(4)) })
        diagText = TextView(this).apply { textSize = 13f }
        root.addView(diagText)
        root.addView(TextView(this).apply {
            text = "ゲームを開く前に、ここでボタンを押して ✅ が出るか確認できます。\n" +
                "うまくいかないときは、この画面のスクショを送ってください。"
            textSize = 12f
            setPadding(0, dp(6), 0, 0)
        })

        return ScrollView(this).apply { addView(root) }
    }

    // ───────────── 完了・リセット ─────────────

    private fun isUnsaved() = draft != Mapping.active(this)

    /** 完了：今の配置で固定する */
    private fun commit() {
        Mapping.save(this, draft)
        draft = Mapping.active(this)
        StickEngine.apply(this)
        toast("この配置で固定しました")
        refreshAll()
    }

    /** リセット：最後に「完了」した配置に戻す */
    private fun revert() {
        if (!isUnsaved()) {
            toast("変更はありません（最後に完了した配置のままです）")
            return
        }
        draft = Mapping.active(this)
        toast("最後に完了した配置に戻しました")
        refreshAll()
    }

    private fun confirmClearAll() {
        AlertDialog.Builder(this)
            .setTitle("すべて初期状態に戻しますか？")
            .setMessage("入れ替えと連打の設定がすべて消えます（「完了」を押すと確定します）")
            .setPositiveButton("戻す") { _, _ ->
                draft = Profile(intervalMs = draft.intervalMs, burst = draft.burst)
                refreshAll()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    // ───────────── ボタン 1 つの設定 ─────────────

    private fun openEditor(code: Int) {
        val cur = draft.buttons[code] ?: ButtonConfig()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        box.addView(TextView(this).apply { text = "押したときにゲームに届くボタン"; textSize = 15f })
        val options = listOf("そのまま（${Mapping.nameOf(code)}）") + Mapping.CODES.map { Mapping.nameOf(it) }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            val idx = Mapping.CODES.indexOf(cur.target ?: -1)
            setSelection(if (idx >= 0) idx + 1 else 0)
        }
        box.addView(spinner)

        val turboSwitch = Switch(this).apply {
            text = "連打（ポン押しで ${draft.burst} 回殴る・長押しは 1 回）"
            textSize = 15f
            isChecked = cur.turbo
            setPadding(0, dp(16), 0, dp(8))
        }
        box.addView(turboSwitch)
        box.addView(TextView(this).apply {
            text = "回数やスピードは「⚙ 設定」で変えられます"
            textSize = 12f
        })

        AlertDialog.Builder(this)
            .setTitle("「${Mapping.nameOf(code)}」ボタン")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val pos = spinner.selectedItemPosition
                val target = if (pos == 0) null else Mapping.CODES[pos - 1]
                val c = ButtonConfig(target = target?.takeIf { it != code }, turbo = turboSwitch.isChecked)
                draft = draft.copy(buttons = draft.buttons.toMutableMap().apply {
                    if (c.isDefault) remove(code) else put(code, c)
                })
                refreshAll()
            }
            .setNeutralButton("このボタンを元に戻す") { _, _ ->
                draft = draft.copy(buttons = draft.buttons - code)
                refreshAll()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    // ───────────── 設定 ─────────────

    private fun openSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        val burstLabel = TextView(this).apply { textSize = 15f }
        val burstBar = SeekBar(this).apply { max = Mapping.MAX_BURST - 1; progress = draft.burst - 1 }
        val speedLabel = TextView(this).apply { textSize = 15f; setPadding(0, dp(16), 0, 0) }
        val speedBar = SeekBar(this).apply {
            max = (Mapping.MAX_INTERVAL - Mapping.MIN_INTERVAL) / 10
            progress = (draft.intervalMs - Mapping.MIN_INTERVAL) / 10
        }
        val resultLabel = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(16), 0, 0)
            setTypeface(typeface, Typeface.BOLD)
        }

        fun burst() = burstBar.progress + 1
        fun interval() = Mapping.MIN_INTERVAL + speedBar.progress * 10
        fun update() {
            burstLabel.text = "1 回押したら何回殴るか：${burst()} 回"
            speedLabel.text = String.format("連打のスピード：%.2f 秒に 1 回（1 秒に約 %.0f 回）",
                interval() / 1000f, 1000f / interval())
            val total = burst() * interval()
            resultLabel.text = "→ 1 秒に 1 回押すと、1 秒に ${burst()} 回殴ります" +
                if (total > 1000) "\n⚠ スピードが遅くて 1 秒に収まりません（${String.format("%.1f", total / 1000f)} 秒かかります）。スピードを上げてください"
                else "（${String.format("%.2f", total / 1000f)} 秒で全部出ます）"
        }
        val l = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = update()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        burstBar.setOnSeekBarChangeListener(l)
        speedBar.setOnSeekBarChangeListener(l)
        update()

        box.addView(burstLabel)
        box.addView(burstBar)
        box.addView(speedLabel)
        box.addView(speedBar)
        box.addView(resultLabel)

        // ── 振り向き感度（実験） ──
        box.addView(TextView(this).apply {
            text = "🧪 振り向き感度（右スティック・実験）"
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(24), 0, dp(4))
        })
        val stickSwitch = Switch(this).apply {
            text = "振り向き感度を変える"
            textSize = 15f
            isChecked = draft.stickOn
        }
        box.addView(stickSwitch)
        val modeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val normalBtn = RadioButton(this).apply { text = "普通"; id = View.generateViewId() }
        val pcBtn = RadioButton(this).apply { text = "PC版"; id = View.generateViewId() }
        modeGroup.addView(normalBtn)
        modeGroup.addView(pcBtn)
        modeGroup.check(if (draft.stickMode == 1) pcBtn.id else normalBtn.id)
        box.addView(modeGroup)
        val multLabel = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, 0) }
        val multBar = SeekBar(this).apply { max = 35; progress = (draft.stickMult - 5).coerceIn(0, 35) }
        fun multValue() = multBar.progress + 5
        fun updateMult() {
            multLabel.text = String.format("倍率：%.1f 倍", multValue() / 10f) +
                if (modeGroup.checkedRadioButtonId == pcBtn.id)
                    "（PC版：少し倒しただけで一気に速く回る）"
                else "（普通：右に倒した量 × 倍率）"
        }
        multBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = updateMult()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        modeGroup.setOnCheckedChangeListener { _, _ -> updateMult() }
        updateMult()
        box.addView(multLabel)
        box.addView(multBar)
        box.addView(TextView(this).apply {
            text = "※ 最大の回る速さはマイクラ側の「コントローラー感度」で決まります。マイクラ側も最大にしてください。\n" +
                "※ 動作中は、コントローラーの入力をこのアプリが代わりに全部送ります。おかしくなったらここを OFF にして「完了」を押すか、コントローラーをつなぎ直してください。\n" +
                "※ ON にする前に、コントローラーのボタンを全部 1 回ずつ押しておくと、ボタンの対応を覚えて正確になります。"
            textSize = 12f
            setPadding(0, dp(8), 0, 0)
        })
        box.addView(TextView(this).apply {
            text = "※ ポンと押すと上の回数だけ殴ります。\n" +
                "※ 長押し（0.25 秒以上）すると普通の長押し 1 回になります（ブロック壊しなど）。\n" +
                "※ 連打はボタンをタップして「連打」を ON にしたボタンだけに効きます。"
            textSize = 12f
            setPadding(0, dp(16), 0, 0)
        })

        AlertDialog.Builder(this)
            .setTitle("⚙ 設定（OK のあと「完了」で反映）")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK") { _, _ ->
                draft = draft.copy(
                    intervalMs = interval(), burst = burst(),
                    stickOn = stickSwitch.isChecked,
                    stickMode = if (modeGroup.checkedRadioButtonId == pcBtn.id) 1 else 0,
                    stickMult = multValue(),
                )
                refreshAll()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    // ───────────── 表示の更新 ─────────────

    private fun refreshAll() {
        if (!uiReady) return
        refreshStatus()
        refreshStyle()
        refreshConfigs()
        refreshDiag()
    }

    private fun refreshConfigs() {
        controller.configs = draft.buttons
        summaryText.text = (if (draft.buttons.isEmpty()) {
            "変更なし"
        } else {
            "配置：\n" + Mapping.CODES.mapNotNull { code ->
                val c = draft.buttons[code] ?: return@mapNotNull null
                val parts = mutableListOf<String>()
                c.target?.let { parts += "→ ${Mapping.nameOf(it)}" }
                if (c.turbo) parts += "⚡連打"
                "・${Mapping.nameOf(code)} ${parts.joinToString("  ")}"
            }.joinToString("\n")
        }) + "\n連打：1 回押すと ${draft.burst} 回 / " +
            String.format("%.2f 秒に 1 回", draft.intervalMs / 1000f) +
            "\n振り向き感度：" + (if (!draft.stickOn) "OFF" else
                (if (draft.stickMode == 1) "PC版 " else "普通 ") + String.format("%.1f 倍", draft.stickMult / 10f))

        unsavedText.text = if (isUnsaved())
            "⚠ まだ反映されていません。「完了」を押すとゲームに反映されます"
        else "✅ この配置で固定されています"
    }

    private fun refreshStatus() {
        if (!uiReady) return
        val a11y = accessibilityEnabled()
        val shizukuRunning = Injector.shizukuRunning()
        val shizukuOk = Injector.hasPermission()
        statusText.text = "ユーザー補助: ${if (a11y) "✅ ON" else "❌ OFF"}\n" +
            "Shizuku: " + when {
                !shizukuRunning -> "❌ 起動していません"
                !shizukuOk -> "⚠️ 権限がありません"
                else -> "✅ OK"
            }
        val problems = mutableListOf<String>()
        if (!a11y) problems += "・ユーザー補助が OFF です → ① を押して「ボタン入れ替え」を ON"
        if (!shizukuRunning) problems += "・Shizuku が起動していません → Shizuku アプリを開いて「開始」"
        else if (!shizukuOk) problems += "・Shizuku の許可がありません → ② を押して許可"
        warnText.text = if (problems.isEmpty()) "" else "このままでは動きません：\n" + problems.joinToString("\n")
        warnText.visibility = if (problems.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun refreshStyle() {
        val name = Pad.connectedName()
        styleText.text = "今の表示: ${Pad.style.title}" +
            (if (name != null) "\nつながっているコントローラー: $name" else "\nコントローラーがつながっていません") +
            "\n押したボタンと違う場所が光るときは、種類を変えるか下のボタンを押してください"
        byLabelButton.visibility = if (Pad.style == PadStyle.NINTENDO) View.VISIBLE else View.GONE
        byLabelButton.text = if (Pad.nintendoByLabel) "Switch の A/B・X/Y：表記どおり（タップで切替）"
            else "Switch の A/B・X/Y：位置どおり（タップで切替）"
    }

    private fun refreshDiag() {
        if (!uiReady) return
        diagText.text = "サービス: ${if (Diag.serviceConnected) "✅ 動いています" else "❌ 動いていません"}\n" +
            "サービスが受け取ったボタン: ${Diag.lastReceived}\n" +
            "結果: ${Diag.lastResult}\n" +
            "振り向き感度: ${Diag.stickStatus}"
    }

    // ───────────── その他 ─────────────

    private fun requestShizuku() {
        when {
            !Injector.shizukuRunning() ->
                toast("Shizuku が起動していません。Shizuku アプリで「開始」してください")
            Shizuku.isPreV11() -> toast("Shizuku が古いので更新してください")
            Injector.hasPermission() -> toast("すでに許可されています")
            Shizuku.shouldShowRequestPermissionRationale() ->
                toast("Shizuku アプリの中で、このアプリを許可してください")
            else -> Shizuku.requestPermission(1)
        }
    }

    private fun accessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, RemapService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun title(t: String, size: Float) = TextView(this).apply {
        text = t
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
