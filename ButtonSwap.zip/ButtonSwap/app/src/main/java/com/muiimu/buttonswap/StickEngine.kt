package com.muiimu.buttonswap

import android.content.Context
import android.util.Log
import android.view.InputDevice
import android.view.MotionEvent
import java.util.concurrent.Executors

/**
 * 【実験】振り向き感度（右スティック）を動かす・止める係（アプリ側）。
 * 実際の処理は Shizuku の権限で動く ShellService の中（StickCore）で行う。
 * Android のセキュリティで、コントローラーの生データはアプリに直接渡せないため。
 */
object StickEngine {
    private const val TAG = "StickEngine"

    private val control = Executors.newSingleThreadExecutor()

    @Volatile private var runningDeviceId: Int? = null

    fun isRunning() = runningDeviceId != null

    /** 設定に合わせて、動かす・止める・設定を反映する */
    fun apply(ctx: Context) {
        val app = ctx.applicationContext
        Shell.init(app)
        control.execute {
            try {
                applyNow(app)
            } catch (t: Throwable) {
                Log.e(TAG, "apply failed", t)
                Diag.stick("❌ エラー: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    fun stop() {
        control.execute {
            try { Shell.service()?.stopStick() } catch (t: Throwable) {}
            runningDeviceId = null
            enableAll()
            Diag.stick("停止中")
        }
    }

    /**
     * 念のため、つながっているコントローラーを全部 Android に戻す。
     * （前に動かしていたときにアプリが落ちていても、ここで元に戻る）
     */
    private fun enableAll() {
        if (!Injector.ready()) return
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if ((d.sources and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) continue
            try { Injector.callInputManager("enableInputDevice", id) } catch (t: Throwable) {}
        }
    }

    private fun applyNow(ctx: Context) {
        val p = Mapping.active(ctx)
        val mode = p.stickMode
        val mult = p.stickMult / 10f

        // 動作中か確認（コントローラーが切れて止まっていることもある）
        if (runningDeviceId != null) {
            val svc = Shell.service()
            val alive = try { svc?.stickRunning() == true } catch (t: Throwable) { false }
            if (!alive) {
                val why = try { svc?.stickError() ?: "" } catch (t: Throwable) { "" }
                runningDeviceId = null
                Diag.stick(if (why.isNotEmpty()) "止まりました（$why）" else "コントローラー待ち")
            }
        }

        if (runningDeviceId != null) {
            if (!p.stickOn || !Injector.ready()) {
                try { Shell.service()?.stopStick() } catch (t: Throwable) {}
                runningDeviceId = null
                enableAll()
                Diag.stick("停止中")
            } else {
                try { Shell.service()?.setStick(mode, mult, p.stickDeadzone) } catch (t: Throwable) {}
                Diag.stick("✅ 動作中（${modeName(mode)} ${"%.1f".format(mult)} 倍）")
            }
            return
        }

        if (!p.stickOn) { enableAll(); Diag.stick("停止中"); return }
        // ユーザー補助が動いていないと、アプリが閉じられたときに止められなくなるので動かさない
        if (!Diag.serviceConnected) { Diag.stick("❌ ユーザー補助が OFF です"); return }
        if (!Injector.ready()) { Diag.stick("❌ Shizuku が使えません"); return }
        val pad = findController() ?: run { Diag.stick("コントローラー待ち"); return }

        Diag.stick("準備中…")
        val info = Shell.run("getevent -p", 4)
            ?: return Diag.stick("❌ Shizuku でコマンドを動かせません（${Shell.lastError}）")
        val node = Shell.findNode(info, pad.name)
            ?: return Diag.stick("❌ コントローラーの生データの場所が見つかりません")
        val ranges = Shell.absRanges(info, node)
        if (ranges.isEmpty()) return Diag.stick("❌ スティックの情報が読めません")

        // Android 側がどの軸名を使っているか
        val padAxes = pad.motionRanges.map { it.axis }.toSet()
        val rightIsRxRy = MotionEvent.AXIS_RX in padAxes && MotionEvent.AXIS_RY in padAxes &&
            MotionEvent.AXIS_Z !in padAxes
        val rightX = if (rightIsRxRy) MotionEvent.AXIS_RX else MotionEvent.AXIS_Z
        val rightY = if (rightIsRxRy) MotionEvent.AXIS_RY else MotionEvent.AXIS_RZ

        val pairs = ArrayList<Int>()
        fun map(code: Int, vararg axes: Int) {
            if (code !in ranges) return
            for (a in axes) { pairs += code; pairs += a }
        }
        map(0x00, MotionEvent.AXIS_X)
        map(0x01, MotionEvent.AXIS_Y)
        if (0x03 in ranges && 0x04 in ranges) {
            // ABS_RX / ABS_RY が右スティック、ABS_Z / ABS_RZ はトリガー
            map(0x03, rightX)
            map(0x04, rightY)
            map(0x02, MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_BRAKE)
            map(0x05, MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_GAS)
        } else {
            // ABS_Z / ABS_RZ が右スティックの機種
            map(0x02, rightX)
            map(0x05, rightY)
        }
        map(0x09, MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_GAS)
        map(0x0a, MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_BRAKE)
        map(0x10, MotionEvent.AXIS_HAT_X)
        map(0x11, MotionEvent.AXIS_HAT_Y)

        val rangeData = ArrayList<Int>()
        for ((code, r) in ranges) {
            rangeData += code; rangeData += r[0]; rangeData += r[1]; rangeData += r[2]; rangeData += r[3]
        }

        val keyPairs = ArrayList<Int>()
        for ((scan, key) in ScanMap.all(ctx)) { keyPairs += scan; keyPairs += key }

        val svc = Shell.service()
            ?: return Diag.stick("❌ Shizuku のサービスにつながりません（${Shell.lastError}）")
        val err = try {
            svc.startStick(
                node, pad.id, pairs.toIntArray(), rangeData.toIntArray(),
                rightX, rightY, keyPairs.toIntArray(), mode, mult, p.stickDeadzone
            )
        } catch (t: Throwable) {
            "${t.javaClass.simpleName}: ${t.message}"
        }
        if (err.isNotEmpty()) return Diag.stick("❌ $err")

        runningDeviceId = pad.id
        Diag.stick("✅ 動作中（${modeName(mode)} ${"%.1f".format(mult)} 倍）")
    }

    fun modeName(mode: Int) = if (mode == 1) "PC版" else "普通"

    private fun findController(): InputDevice? {
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            if ((d.sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) return d
        }
        return null
    }
}
