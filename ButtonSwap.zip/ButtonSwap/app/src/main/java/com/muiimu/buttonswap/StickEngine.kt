package com.muiimu.buttonswap

import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import java.io.DataInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sign

/**
 * 【実験】振り向き感度（右スティック）を変える仕組み。
 *
 *  1. Shizuku の権限でコントローラーの生データ（/dev/input/eventX）を読む
 *  2. コントローラーを Android から一時的に切り離す（元の入力がゲームに二重に届かないように）
 *  3. 右スティックの値を感度に合わせて変えてから、スティックとボタンを全部ゲームに送り直す
 *
 * 止めるときは必ずコントローラーを元に戻す。
 */
object StickEngine {
    private const val TAG = "StickEngine"

    private const val EV_SYN = 0
    private const val EV_KEY = 1
    private const val EV_ABS = 3

    private val control = Executors.newSingleThreadExecutor()

    @Volatile private var running: Running? = null

    /** 感度の設定（動作中でもすぐ反映される） */
    @Volatile var mode = 0          // 0=普通, 1=PC版
    @Volatile var mult = 2.0f        // 倍率

    private class Running(
        val deviceId: Int,
        val name: String,
        val proc: Process,
        val axisMap: Map<Int, IntArray>,     // ABS コード → Android の軸
        val ranges: Map<Int, IntArray>,      // ABS コード → min, max, flat
        val rightX: Int,
        val rightY: Int,
    ) {
        @Volatile var stopped = false
        val raw = HashMap<Int, Int>()
        val keyDown = java.util.concurrent.ConcurrentHashMap<Int, Long>()   // 押しているボタン（keyCode → 押した時刻）
    }

    fun isRunning() = running != null

    /** 設定に合わせて、動かす・止める・設定を反映する */
    fun apply(ctx: Context) {
        val app = ctx.applicationContext
        control.execute {
            try {
                applyNow(app)
            } catch (t: Throwable) {
                Log.e(TAG, "apply failed", t)
                Diag.stick("❌ エラー: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    fun stop() {
        control.execute { stopNow("停止中") }
    }

    private fun applyNow(ctx: Context) {
        val p = Mapping.active(ctx)
        mode = p.stickMode
        mult = p.stickMult / 10f

        val want = p.stickOn && Injector.ready()
        val cur = running
        if (cur != null) {
            if (!want) stopNow(if (p.stickOn) "❌ Shizuku が使えないので止めました" else "停止中")
            return // 動作中なら設定の反映だけ
        }
        if (!p.stickOn) { Diag.stick("停止中"); return }
        // ユーザー補助が動いていないと、アプリが閉じられたときにコントローラーが切り離されたままになるので動かさない
        if (!Diag.serviceConnected) { Diag.stick("❌ ユーザー補助が OFF です"); return }
        if (!Injector.ready()) { Diag.stick("❌ Shizuku が使えません"); return }
        val pad = findController() ?: run { Diag.stick("コントローラー待ち"); return }
        startNow(ctx, pad)
    }

    private fun startNow(ctx: Context, pad: InputDevice) {
        Diag.stick("準備中…")
        val info = Shell.run("getevent -p", 4)
            ?: return Diag.stick("❌ Shizuku でコマンドを動かせません")
        val node = Shell.findNode(info, pad.name)
            ?: return Diag.stick("❌ コントローラーの生データの場所が見つかりません")
        val ranges = Shell.absRanges(info, node)
        if (ranges.isEmpty()) return Diag.stick("❌ スティックの情報が読めません")

        // Android 側がどの軸名を使っているか
        val padAxes = pad.motionRanges.map { it.axis }.toSet()
        val rightIsRxRy = MotionEvent.AXIS_RX in padAxes && MotionEvent.AXIS_RY in padAxes &&
            MotionEvent.AXIS_Z !in padAxes
        val rightX = if (rightIsRxRy) MotionEvent.AXIS_RX else MotionEvent.AXIS_Z
        val rightY = if (rightIsRxRy) MotionEvent.AXIS_RY else MotionEvent.AXIS_RZ

        val axisMap = HashMap<Int, IntArray>()
        axisMap[0x00] = intArrayOf(MotionEvent.AXIS_X)
        axisMap[0x01] = intArrayOf(MotionEvent.AXIS_Y)
        if (0x03 in ranges && 0x04 in ranges) {
            // ABS_RX / ABS_RY が右スティック、ABS_Z / ABS_RZ はトリガー
            axisMap[0x03] = intArrayOf(rightX)
            axisMap[0x04] = intArrayOf(rightY)
            axisMap[0x02] = intArrayOf(MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_BRAKE)
            axisMap[0x05] = intArrayOf(MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_GAS)
        } else {
            // ABS_Z / ABS_RZ が右スティックの機種
            axisMap[0x02] = intArrayOf(rightX)
            axisMap[0x05] = intArrayOf(rightY)
        }
        axisMap[0x09] = intArrayOf(MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_GAS)
        axisMap[0x0a] = intArrayOf(MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_BRAKE)
        axisMap[0x10] = intArrayOf(MotionEvent.AXIS_HAT_X)
        axisMap[0x11] = intArrayOf(MotionEvent.AXIS_HAT_Y)
        axisMap.keys.retainAll(ranges.keys)

        // 生データを読み始める（cat は読んだ分をすぐ流してくれる）
        val proc = try {
            Shell.newProcess("cat $node")
        } catch (t: Throwable) {
            return Diag.stick("❌ 生データを読めません: ${t.message}")
        }

        // コントローラーを Android から切り離す
        try {
            Injector.callInputManager("disableInputDevice", pad.id)
        } catch (t: Throwable) {
            proc.destroy()
            val c = t.cause ?: t
            return Diag.stick("❌ コントローラーを切り離せません: ${c.javaClass.simpleName}: ${c.message}")
        }

        val r = Running(pad.id, pad.name, proc, axisMap, ranges, rightX, rightY)
        running = r
        Thread({ readLoop(ctx, r) }, "stick-reader").start()
        Diag.stick("✅ 動作中（${pad.name}）")
    }

    private fun stopNow(status: String) {
        val r = running ?: run { Diag.stick(status); return }
        running = null
        r.stopped = true
        // 押しっぱなしのボタンを離す
        for ((key, down) in r.keyDown) {
            try {
                Injector.injectNow(keyEvent(r, down, KeyEvent.ACTION_UP, key, 0))
            } catch (t: Throwable) {
            }
        }
        r.keyDown.clear()
        try { r.proc.destroy() } catch (t: Throwable) {}
        restore(r.deviceId)
        Diag.stick(status)
    }

    /** コントローラーを Android に戻す */
    private fun restore(deviceId: Int) {
        try {
            Injector.callInputManager("enableInputDevice", deviceId)
        } catch (t: Throwable) {
            Log.e(TAG, "enable failed", t)
        }
    }

    // ───── 生データを読んで送り直す ─────

    private fun readLoop(ctx: Context, r: Running) {
        val size = if (Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) 24 else 16
        val buf = ByteArray(size)
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        var dirty = false
        try {
            val ins = DataInputStream(r.proc.inputStream)
            while (!r.stopped) {
                ins.readFully(buf)
                val type = bb.getShort(size - 8).toInt() and 0xffff
                val code = bb.getShort(size - 6).toInt() and 0xffff
                val value = bb.getInt(size - 4)
                when (type) {
                    EV_ABS -> { r.raw[code] = value; dirty = true }
                    EV_KEY -> handleKey(ctx, r, code, value)
                    EV_SYN -> if (code == 0 && dirty) { emitMotion(r); dirty = false }
                }
            }
        } catch (t: Throwable) {
            if (!r.stopped) Log.e(TAG, "read loop ended", t)
        }
        if (!r.stopped) {
            // コントローラーが切れたなど
            control.execute { if (running === r) stopNow("コントローラー待ち") }
        }
    }

    private fun handleKey(ctx: Context, r: Running, scan: Int, value: Int) {
        if (value == 2) return // 長押しのリピートは無視
        val key = ScanMap.keyFor(ctx, scan) ?: return
        val now = SystemClock.uptimeMillis()
        if (value == 1) {
            r.keyDown[key] = now
            Injector.injectNow(keyEvent(r, now, KeyEvent.ACTION_DOWN, key, scan))
        } else {
            val down = r.keyDown.remove(key) ?: now
            Injector.injectNow(keyEvent(r, down, KeyEvent.ACTION_UP, key, scan))
        }
    }

    private fun keyEvent(r: Running, down: Long, action: Int, key: Int, scan: Int): KeyEvent {
        var src = InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_KEYBOARD
        if (key in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT) src = src or InputDevice.SOURCE_DPAD
        // scanCode は本物と同じにしておく（ボタン入れ替え・連打の設定がそのまま効くように）
        return KeyEvent(down, SystemClock.uptimeMillis(), action, key, 0, 0, r.deviceId, scan, 0, src)
    }

    private val props = arrayOf(MotionEvent.PointerProperties().apply {
        id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN
    })

    private fun emitMotion(r: Running) {
        val c = MotionEvent.PointerCoords()
        for ((code, axes) in r.axisMap) {
            val raw = r.raw[code] ?: continue
            val range = r.ranges[code] ?: continue
            for (axis in axes) c.setAxisValue(axis, normalize(axis, raw, range))
        }

        // 右スティックに感度をかける
        val x = c.getAxisValue(r.rightX)
        val y = c.getAxisValue(r.rightY)
        val len = hypot(x, y)
        if (len > 0f) {
            val m = mult
            val out = when (mode) {
                1 -> len.pow(0.5f) * m   // PC版：少し倒しただけで一気に速くなる
                else -> len * m          // 普通：倍率をかけるだけ
            }.coerceAtMost(1f)
            val k = out / len
            c.setAxisValue(r.rightX, (x * k).coerceIn(-1f, 1f))
            c.setAxisValue(r.rightY, (y * k).coerceIn(-1f, 1f))
        }

        val now = SystemClock.uptimeMillis()
        val ev = MotionEvent.obtain(
            now, now, MotionEvent.ACTION_MOVE, 1, props, arrayOf(c),
            0, 0, 1f, 1f, r.deviceId, 0, InputDevice.SOURCE_JOYSTICK, 0
        )
        try {
            Injector.injectNow(ev)
        } finally {
            ev.recycle()
        }
    }

    /** 生の値を Android と同じ範囲（スティック -1〜1、トリガー 0〜1）に直す */
    private fun normalize(axis: Int, raw: Int, range: IntArray): Float {
        val min = range[0].toFloat()
        val max = range[1].toFloat()
        if (max <= min) return 0f
        return when (axis) {
            MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y -> raw.toFloat().sign
            MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER,
            MotionEvent.AXIS_GAS, MotionEvent.AXIS_BRAKE ->
                ((raw - min) / (max - min)).coerceIn(0f, 1f)
            else -> {
                val center = (min + max) / 2f
                val half = (max - min) / 2f
                val v = ((raw - center) / half).coerceIn(-1f, 1f)
                val flat = if (range[2] > 0) range[2] / half else 0.05f
                if (abs(v) < flat) 0f else v
            }
        }
    }

    private fun findController(): InputDevice? {
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            if ((d.sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) return d
        }
        return null
    }
}
