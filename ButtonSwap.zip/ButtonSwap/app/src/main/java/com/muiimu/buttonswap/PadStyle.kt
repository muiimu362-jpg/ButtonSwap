package com.muiimu.buttonswap

import android.content.Context
import android.view.InputDevice
import android.view.KeyEvent

/** コントローラーの種類。ボタンの表示名と、絵の中の ABXY の位置が変わる */
enum class PadStyle(val title: String) {
    NINTENDO("Switch"),
    PLAYSTATION("PlayStation"),
    XBOX("Xbox・その他"),
}

/**
 * Android はボタンを「位置」で扱う（下=BUTTON_A, 右=BUTTON_B, 左=BUTTON_X, 上=BUTTON_Y）。
 * ここでコントローラーごとの「印刷されている名前」に変換する。
 */
object Pad {
    const val NORTH = 0
    const val EAST = 1
    const val SOUTH = 2
    const val WEST = 3

    @Volatile var style: PadStyle = PadStyle.NINTENDO
    /** Switch で、Android が位置ではなく印刷どおりの名前で送ってくる機種用 */
    @Volatile var nintendoByLabel: Boolean = false

    private const val PREFS = "pad"

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        style = PadStyle.entries.getOrNull(p.getInt("style", -1)) ?: detect() ?: PadStyle.NINTENDO
        nintendoByLabel = p.getBoolean("byLabel", false)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("style", style.ordinal)
            .putBoolean("byLabel", nintendoByLabel)
            .apply()
    }

    fun hasSavedStyle(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains("style")

    /** つながっているコントローラーのメーカーから自動判定 */
    fun detect(): PadStyle? {
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if ((d.sources and InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD) continue
            styleOfVendor(d.vendorId)?.let { return it }
        }
        return null
    }

    fun styleOfVendor(vendorId: Int): PadStyle? = when (vendorId) {
        0x057e -> PadStyle.NINTENDO     // 任天堂
        0x054c -> PadStyle.PLAYSTATION  // ソニー
        0x045e -> PadStyle.XBOX         // マイクロソフト
        else -> null
    }

    fun connectedName(): String? {
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if ((d.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD) return d.name
        }
        return null
    }

    /** ABXY が絵のどの位置にあるか */
    fun facePos(code: Int): Int {
        val byLabel = style == PadStyle.NINTENDO && nintendoByLabel
        return when (code) {
            KeyEvent.KEYCODE_BUTTON_A -> if (byLabel) EAST else SOUTH
            KeyEvent.KEYCODE_BUTTON_B -> if (byLabel) SOUTH else EAST
            KeyEvent.KEYCODE_BUTTON_X -> if (byLabel) NORTH else WEST
            KeyEvent.KEYCODE_BUTTON_Y -> if (byLabel) WEST else NORTH
            else -> -1
        }
    }

    fun label(code: Int): String {
        val pos = facePos(code)
        if (pos >= 0) {
            return when (style) {
                PadStyle.NINTENDO -> arrayOf("X", "A", "B", "Y")[pos]
                PadStyle.PLAYSTATION -> arrayOf("△", "○", "×", "□")[pos]
                PadStyle.XBOX -> arrayOf("Y", "B", "A", "X")[pos]
            }
        }
        return when (code) {
            KeyEvent.KEYCODE_BUTTON_L1 -> pick("L", "L1", "LB")
            KeyEvent.KEYCODE_BUTTON_R1 -> pick("R", "R1", "RB")
            KeyEvent.KEYCODE_BUTTON_L2 -> pick("ZL", "L2", "LT")
            KeyEvent.KEYCODE_BUTTON_R2 -> pick("ZR", "R2", "RT")
            KeyEvent.KEYCODE_BUTTON_THUMBL -> pick("LS", "L3", "LS")
            KeyEvent.KEYCODE_BUTTON_THUMBR -> pick("RS", "R3", "RS")
            KeyEvent.KEYCODE_BUTTON_START -> pick("＋", "OPT", "≡")
            KeyEvent.KEYCODE_BUTTON_SELECT -> pick("－", "SHARE", "⧉")
            KeyEvent.KEYCODE_DPAD_UP -> "↑"
            KeyEvent.KEYCODE_DPAD_DOWN -> "↓"
            KeyEvent.KEYCODE_DPAD_LEFT -> "←"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "→"
            else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
        }
    }

    private fun pick(n: String, p: String, x: String) = when (style) {
        PadStyle.NINTENDO -> n
        PadStyle.PLAYSTATION -> p
        PadStyle.XBOX -> x
    }
}
