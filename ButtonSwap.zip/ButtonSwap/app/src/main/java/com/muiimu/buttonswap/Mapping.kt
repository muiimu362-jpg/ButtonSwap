package com.muiimu.buttonswap

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent

/** 1 つのボタンの設定 */
data class ButtonConfig(
    /** ゲームに届けるボタン（null ならそのまま） */
    val target: Int? = null,
    /** 連射 ON/OFF */
    val turbo: Boolean = false,
    /** 連射の間隔（ミリ秒）。100 なら 0.1 秒ごとに 1 回押す */
    val intervalMs: Int = 100,
    /** 1 回押しただけで最低何回押したことにするか */
    val burst: Int = 1,
) {
    val isDefault get() = target == null && !turbo
}

/** ボタンごとの設定を保存・読み込みする */
object Mapping {
    private const val PREFS = "mapping_v2"

    const val MIN_INTERVAL = 30
    const val MAX_INTERVAL = 1000
    const val MAX_BURST = 5

    /** 設定できるボタン */
    val CODES: List<Int> = listOf(
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
        KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
        KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
        KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR,
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
    )

    /** （表示名, キーコード）。表示名はコントローラーの種類で変わる */
    val BUTTONS: List<Pair<String, Int>> get() = CODES.map { Pad.label(it) to it }

    fun nameOf(code: Int): String = Pad.label(code)

    @Volatile private var cache: Map<Int, ButtonConfig>? = null
    private var listener: SharedPreferences.OnSharedPreferenceChangeListener? = null

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 設定がなければ null */
    fun config(ctx: Context, code: Int): ButtonConfig? = (cache ?: load(ctx))[code]

    fun all(ctx: Context): Map<Int, ButtonConfig> = cache ?: load(ctx)

    fun set(ctx: Context, code: Int, cfg: ButtonConfig) {
        val e = prefs(ctx).edit()
        val k = code.toString()
        if (cfg.isDefault) {
            e.remove("t_$k").remove("turbo_$k").remove("int_$k").remove("burst_$k")
        } else {
            if (cfg.target == null || cfg.target == code) e.remove("t_$k") else e.putInt("t_$k", cfg.target)
            e.putBoolean("turbo_$k", cfg.turbo)
            e.putInt("int_$k", cfg.intervalMs.coerceIn(MIN_INTERVAL, MAX_INTERVAL))
            e.putInt("burst_$k", cfg.burst.coerceIn(1, MAX_BURST))
        }
        e.apply()
        cache = null
    }

    fun clear(ctx: Context) {
        prefs(ctx).edit().clear().apply()
        cache = null
    }

    @Synchronized
    private fun load(ctx: Context): Map<Int, ButtonConfig> {
        val p = prefs(ctx)
        if (listener == null) {
            // 設定画面で変更されたら、サービス側も読み直す
            val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> cache = null }
            p.registerOnSharedPreferenceChangeListener(l)
            listener = l
        }
        val m = HashMap<Int, ButtonConfig>()
        for (code in CODES) {
            val k = code.toString()
            val cfg = ButtonConfig(
                target = if (p.contains("t_$k")) p.getInt("t_$k", code) else null,
                turbo = p.getBoolean("turbo_$k", false),
                intervalMs = p.getInt("int_$k", 100),
                burst = p.getInt("burst_$k", 1),
            )
            if (!cfg.isDefault) m[code] = cfg
        }
        cache = m
        return m
    }
}
