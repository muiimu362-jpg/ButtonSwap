package com.muiimu.buttonswap

import android.content.Context
import android.view.KeyEvent

/** 1 つのボタンの設定 */
data class ButtonConfig(
    /** ゲームに届けるボタン（null ならそのまま） */
    val target: Int? = null,
    /** 連打 ON/OFF */
    val turbo: Boolean = false,
) {
    val isDefault get() = target == null && !turbo
}

/** 全体の設定（これを「完了」で保存して固定する） */
data class Profile(
    val buttons: Map<Int, ButtonConfig> = emptyMap(),
    /** 連打の間隔（ミリ秒） */
    val intervalMs: Int = 100,
    /** 1 回押したら何回殴るか */
    val burst: Int = 3,
    /** 【実験】振り向き感度 ON/OFF */
    val stickOn: Boolean = false,
    /** 0=普通, 1=PC版 */
    val stickMode: Int = 0,
    /** 倍率 ×10（20 なら 2.0 倍） */
    val stickMult: Int = 20,
)

/** 保存されている設定（＝今サービスが使っている設定）の読み書き */
object Mapping {
    private const val PREFS = "profile_v3"

    const val MIN_INTERVAL = 30
    const val MAX_INTERVAL = 500
    const val MAX_BURST = 10

    /** 設定できるボタン */
    val CODES: List<Int> = listOf(
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
        KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
        KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
        KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR,
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
    )

    fun nameOf(code: Int): String = Pad.label(code)

    @Volatile private var cache: Profile? = null

    /** 保存済みの設定 */
    fun active(ctx: Context): Profile = cache ?: load(ctx)

    /** 「完了」：この設定で固定する */
    fun save(ctx: Context, p: Profile) {
        val e = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear()
        for ((code, c) in p.buttons) {
            if (c.isDefault) continue
            c.target?.let { e.putInt("t_$code", it) }
            e.putBoolean("turbo_$code", c.turbo)
        }
        e.putInt("interval", p.intervalMs.coerceIn(MIN_INTERVAL, MAX_INTERVAL))
        e.putInt("burst", p.burst.coerceIn(1, MAX_BURST))
        e.putBoolean("stickOn", p.stickOn)
        e.putInt("stickMode", p.stickMode)
        e.putInt("stickMult", p.stickMult.coerceIn(5, 40))
        e.commit()
        cache = p.copy(buttons = p.buttons.filterValues { !it.isDefault })
    }

    @Synchronized
    private fun load(ctx: Context): Profile {
        val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val m = HashMap<Int, ButtonConfig>()
        for (code in CODES) {
            val c = ButtonConfig(
                target = if (sp.contains("t_$code")) sp.getInt("t_$code", code) else null,
                turbo = sp.getBoolean("turbo_$code", false),
            )
            if (!c.isDefault) m[code] = c
        }
        val p = Profile(
            m, sp.getInt("interval", 100), sp.getInt("burst", 3),
            sp.getBoolean("stickOn", false), sp.getInt("stickMode", 0), sp.getInt("stickMult", 20),
        )
        cache = p
        return p
    }
}
